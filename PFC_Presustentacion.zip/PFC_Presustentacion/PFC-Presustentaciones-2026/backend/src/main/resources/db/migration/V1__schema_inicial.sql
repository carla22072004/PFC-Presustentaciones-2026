 

    create table presus.areas_tematicas (
        id serial not null,
        linea_investigacion_id integer not null,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.bloques_horarios (
        hora_fin time(6) not null,
        hora_inicio time(6) not null,
        id serial not null,
        jornada_id integer not null,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.carreras (
        facultad_id integer not null,
        id serial not null,
        codigo varchar(20) not null unique,
        modalidad_estudio varchar(40),
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.convocatorias_titulacion (
        activa boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        periodo_academico_id integer not null,
        codigo varchar(30) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.disponibilidad_sala (
        bloque_id integer not null,
        disponible boolean not null,
        fecha date not null,
        id bigserial not null,
        sala_id bigint not null,
        motivo varchar(200),
        primary key (id)
    );

    create table presus.estados_cronograma (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_proceso (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_solicitud (
        id serial not null,
        orden smallint not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.evaluaciones_finales (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado_promedio float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        resultado_id integer,
        fecha_calculo timestamp(6) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint not null unique,
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table presus.evaluadores (
        peso float(53) not null,
        tipo_evaluador_id integer not null,
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        miembro_tribunal_id bigint,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table presus.facultades (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.historial_cronograma (
        cronograma_id bigint not null,
        fecha_anterior timestamp(6) not null,
        fecha_cambio timestamp(6) not null,
        fecha_nueva timestamp(6) not null,
        id bigserial not null,
        sala_anterior_id bigint,
        sala_nueva_id bigint,
        usuario_id bigint not null,
        motivo TEXT,
        primary key (id)
    );

    create table presus.historial_estados_solicitud (
        estado_anterior_id integer,
        estado_nuevo_id integer not null,
        fecha_cambio timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null,
        usuario_id bigint not null,
        comentario TEXT,
        primary key (id)
    );

    create table presus.jornadas (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.lineas_investigacion (
        facultad_id integer,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.miembros_tribunal (
        confirmado boolean not null,
        rol_jurado_id integer not null,
        asignado_en timestamp(6) not null,
        docente_id bigint not null,
        id bigserial not null,
        solicitud_id bigint not null,
        primary key (id),
        unique (solicitud_id, docente_id)
    );

    create table presus.modalidades_titulacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table presus.periodos_academicos (
        activo boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(100) not null,
        primary key (id)
    );

    create table presus.resultados_evaluacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_jurado (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_usuario (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.tipos_evaluador (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.tipos_mensaje (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table actas (
        fecha_generacion date not null,
        firmada boolean not null,
        firmada_presidente boolean not null,
        firmada_tutor boolean not null,
        firmada_vocal1 boolean not null,
        firmada_vocal2 boolean not null,
        fecha_firma_presidente timestamp(6),
        fecha_firma_tutor timestamp(6),
        fecha_firma_vocal1 timestamp(6),
        fecha_firma_vocal2 timestamp(6),
        id bigserial not null,
        solicitud_id bigint not null unique,
        archivo_pdf varchar(255),
        observaciones_acta TEXT,
        primary key (id)
    );

    create table anteproyectos (
        fecha_envio date,
        id bigserial not null,
        solicitud_id bigint unique,
        tamano_bytes bigint,
        estado varchar(30),
        sha256_hash varchar(64),
        archivo_pdf varchar(255),
        observaciones TEXT,
        primary key (id)
    );

    create table criterios_rubrica (
        orden integer not null,
        ponderacion float(53) not null,
        id bigserial not null,
        rubrica_id bigint not null,
        nombre varchar(100) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table cronograma (
        bloque_id integer,
        convocatoria_id integer not null,
        duracion_min integer not null,
        estado_id integer not null,
        numero_intento smallint not null,
        creado_en timestamp(6) not null,
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        sala_id bigint not null,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table docente (
        carga_horaria_semanal integer not null,
        disponible boolean not null,
        facultad_id integer,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        area_especialidad varchar(180),
        primary key (id)
    );

    create table estudiante (
        carrera_id integer not null,
        periodo_ingreso_id integer,
        semestre_actual smallint not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        semestre varchar(30),
        telefono varchar(30),
        expediente_codigo varchar(60) unique,
        carrera varchar(180) not null,
        primary key (id)
    );

    create table evaluaciones (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint unique,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table evaluaciones_criterio (
        escala integer not null,
        nota_obtenida float(53) not null,
        criterio_id bigint not null,
        evaluador_id bigint not null,
        id bigserial not null,
        registrado_en timestamp(6) not null,
        solicitud_id bigint not null,
        observacion_auto TEXT,
        observacion_manual TEXT,
        observaciones TEXT,
        primary key (id),
        unique (evaluador_id, criterio_id)
    );

    create table evaluaciones_jurado (
        nota_jurado float(53) not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        jurado_id bigint not null,
        solicitud_id bigint not null,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table notificaciones (
        leida boolean not null,
        fecha timestamp(6),
        id bigserial not null,
        usuario_id bigint,
        mensaje TEXT,
        primary key (id)
    );

    create table rubricas (
        puntaje_maximo float(53) not null,
        id bigserial not null,
        nombre varchar(120) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table sala (
        capacidad integer not null,
        disponible boolean not null,
        id bigserial not null,
        codigo varchar(40) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table solicitud (
        area_tematica_id integer,
        convocatoria_id integer not null,
        estado_id integer not null,
        linea_investigacion_id integer,
        modalidad_titulacion_id integer not null,
        actualizado_en timestamp(6) not null,
        actualizado_por bigint,
        creado_por bigint,
        estudiante_id bigint not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        suspendido_en timestamp(6),
        titulo_tema varchar(300) not null,
        motivo_suspension TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table tutores (
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null unique,
        estado varchar(20) not null,
        observaciones TEXT,
        primary key (id)
    );

    create table tutoria_fases (
        numero_fase integer not null,
        fecha_aprobacion timestamp(6),
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        tamano_pdf_bytes bigint,
        tutor_id bigint not null,
        estado varchar(30) not null,
        sha256_pdf varchar(64),
        archivo_pdf_estudiante varchar(255),
        primary key (id)
    );

    create table tutoria_mensajes (
        leido boolean not null,
        fase_id bigint not null,
        fecha_envio timestamp(6) not null,
        id bigserial not null,
        remitente_id bigint not null,
        tipo varchar(20) not null,
        contenido TEXT not null,
        primary key (id)
    );

    create table usuarios (
        activo boolean not null,
        rol_id integer not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        apellido varchar(255) not null,
        email varchar(255) not null unique,
        email_notificaciones varchar(255),
        nombre varchar(255) not null,
        password varchar(255) not null,
        rol varchar(255) not null,
        telefono varchar(255),
        primary key (id)
    );

    alter table if exists presus.areas_tematicas 
       add constraint FK89neyi3j42yt914y9dsepvx8g 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists presus.bloques_horarios 
       add constraint FKhimm4vkb8aaamcb8ig77qk8jr 
       foreign key (jornada_id) 
       references presus.jornadas;

    alter table if exists presus.carreras 
       add constraint FKpkbqfnd3xcstklurnni1v7hi8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.convocatorias_titulacion 
       add constraint FKkhjxrhwxttrjg54fosa70k0ib 
       foreign key (periodo_academico_id) 
       references presus.periodos_academicos;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKaqxqt9i1aht1anwbwjtnxkjay 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKdnyk315lc3r3lxpja9ff5aa72 
       foreign key (sala_id) 
       references sala;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK1656v7687m5a006ig2dnxdxlq 
       foreign key (resultado_id) 
       references presus.resultados_evaluacion;

    alter table if exists presus.evaluaciones_finales 
       add constraint FKqr6nw8s42apawhtrjaufmemmk 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK6j0y0jr90cysn9b2xomrn2907 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKdcv3fm9ch7f9otbph1sc0kc56 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.evaluadores 
       add constraint FKf2c67wiobryo5c5us94dxo2nj 
       foreign key (miembro_tribunal_id) 
       references presus.miembros_tribunal;

    alter table if exists presus.evaluadores 
       add constraint FK7lfvwr8cap0mtqx82eypyrfkd 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKf7pg14kvrds8f3splp0a3d9m8 
       foreign key (tipo_evaluador_id) 
       references presus.tipos_evaluador;

    alter table if exists presus.historial_cronograma 
       add constraint FKi3w1x79h0hqgek4qn3a3m2j5x 
       foreign key (cronograma_id) 
       references cronograma;

    alter table if exists presus.historial_cronograma 
       add constraint FKaou7dy35isiktfxl0wvrv24c5 
       foreign key (sala_anterior_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKhlaxapi4vhyntrt7m1eukbvb6 
       foreign key (sala_nueva_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKnjwyynwb33g4jaat7k03korot 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKquuy4n6l595u3n1eesse65lm7 
       foreign key (estado_anterior_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKcduxdoctlihmlrf7jc79hktbr 
       foreign key (estado_nuevo_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK27v25jypoybt045dokcm47yul 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK28v16j834n0mxh44jrkouaard 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.lineas_investigacion 
       add constraint FK6mbdout54e5jy49tpaeqijaa8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.miembros_tribunal 
       add constraint FKrvimgktkif6hr7u3w0l2r345q 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.miembros_tribunal 
       add constraint FKii8qums5v0taxx349emm7th6g 
       foreign key (rol_jurado_id) 
       references presus.roles_jurado;

    alter table if exists presus.miembros_tribunal 
       add constraint FKebkpg7s5whbr9va2yvfaf1act 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists actas 
       add constraint FKbe1mhcpm4hh94m47oxihlkh6i 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists anteproyectos 
       add constraint FKnuplmmjrbs76slhxrt6swwytj 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists criterios_rubrica 
       add constraint FKrwb21y79trk780jwtk34aiqr3 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists cronograma 
       add constraint FKch4phbxqt1j7wck6fh34phj62 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists cronograma 
       add constraint FKbp2d8c5i4pgy0mbhae0f5cj78 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists cronograma 
       add constraint FKbt78p9nbvdowoh0dwisdpnk2n 
       foreign key (estado_id) 
       references presus.estados_cronograma;

    alter table if exists cronograma 
       add constraint FKnkurftcc1qsc7alh7276l5uq1 
       foreign key (sala_id) 
       references sala;

    alter table if exists cronograma 
       add constraint FK7wxxnuex9myk4vf3qbr8nm2qn 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists docente 
       add constraint FKroasnisuah9k11docjg9q46w6 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists docente 
       add constraint FKbs42aumodddav4mosgah3bomi 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists estudiante 
       add constraint FK6mibklpfbmshbwm5ly7t6quc1 
       foreign key (carrera_id) 
       references presus.carreras;

    alter table if exists estudiante 
       add constraint FK665t8l4wpufihhoes8s1938ht 
       foreign key (periodo_ingreso_id) 
       references presus.periodos_academicos;

    alter table if exists estudiante 
       add constraint FKmb0c2sqmehp6spvhm53mej2b7 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists evaluaciones 
       add constraint FKcw8bowlxco293tni77pshk0un 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists evaluaciones 
       add constraint FK53hknbr7ctsod58a57sbk99j9 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_criterio 
       add constraint FK704dbpt9dfb9cc4q2frdk1e59 
       foreign key (criterio_id) 
       references criterios_rubrica;

    alter table if exists evaluaciones_criterio 
       add constraint FKdsk8q9dykx4cndxxmyxg679fc 
       foreign key (evaluador_id) 
       references presus.evaluadores;

    alter table if exists evaluaciones_criterio 
       add constraint FKiwxwbpykr3vo23lxeimiwmfji 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_jurado 
       add constraint FK53wpgafopnaoqe0cge5mi09g8 
       foreign key (jurado_id) 
       references presus.miembros_tribunal;

    alter table if exists evaluaciones_jurado 
       add constraint FK3m5avtbjkv8okijdpvnba6br8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists notificaciones 
       add constraint FK1mxbjb81ft61gwlh0kabubndc 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK5lihp07xom3g6aiv6aid1mqoy 
       foreign key (actualizado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FKkocwlitlopkh7puo52h9tncxj 
       foreign key (area_tematica_id) 
       references presus.areas_tematicas;

    alter table if exists solicitud 
       add constraint FK4o0t4min6fnjh6wtewgwetdsc 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists solicitud 
       add constraint FKbslas51apjrlk1sspwjxcahpd 
       foreign key (creado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK3kdfcybjca99ian0k5g1mhhoq 
       foreign key (estado_id) 
       references presus.estados_solicitud;

    alter table if exists solicitud 
       add constraint FK1gfsheb54hb4313592ynmr5u4 
       foreign key (estudiante_id) 
       references estudiante;

    alter table if exists solicitud 
       add constraint FKg1jysw6105nj3u40g1ahsx14l 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists solicitud 
       add constraint FKaxmn3drihjstewcid9a1wjuw9 
       foreign key (modalidad_titulacion_id) 
       references presus.modalidades_titulacion;

    alter table if exists tutores 
       add constraint FKb2xb48y98w51rrxljckb63d92 
       foreign key (docente_id) 
       references docente;

    alter table if exists tutores 
       add constraint FKpva6fxtkmtc7e8y8qh3ci1jg8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists tutoria_fases 
       add constraint FKennbyt8lrhckfi7fwkpw8qgfm 
       foreign key (tutor_id) 
       references tutores;

    alter table if exists tutoria_mensajes 
       add constraint FK6otp7q57xutoo6yhs7m5vkn19 
       foreign key (fase_id) 
       references tutoria_fases;

    alter table if exists tutoria_mensajes 
       add constraint FKj3p4s6quhocjaojcdvw2t8ag2 
       foreign key (remitente_id) 
       references usuarios;

    alter table if exists usuarios 
       add constraint FKku0it797v3701ntswwvl95ei 
       foreign key (rol_id) 
       references presus.roles_usuario;

    create table presus.areas_tematicas (
        id serial not null,
        linea_investigacion_id integer not null,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.bloques_horarios (
        hora_fin time(6) not null,
        hora_inicio time(6) not null,
        id serial not null,
        jornada_id integer not null,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.carreras (
        facultad_id integer not null,
        id serial not null,
        codigo varchar(20) not null unique,
        modalidad_estudio varchar(40),
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.convocatorias_titulacion (
        activa boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        periodo_academico_id integer not null,
        codigo varchar(30) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.disponibilidad_sala (
        bloque_id integer not null,
        disponible boolean not null,
        fecha date not null,
        id bigserial not null,
        sala_id bigint not null,
        motivo varchar(200),
        primary key (id)
    );

    create table presus.estados_cronograma (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_proceso (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_solicitud (
        id serial not null,
        orden smallint not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.evaluaciones_finales (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado_promedio float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        resultado_id integer,
        fecha_calculo timestamp(6) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint not null unique,
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table presus.evaluadores (
        peso float(53) not null,
        tipo_evaluador_id integer not null,
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        miembro_tribunal_id bigint,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table presus.facultades (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.historial_cronograma (
        cronograma_id bigint not null,
        fecha_anterior timestamp(6) not null,
        fecha_cambio timestamp(6) not null,
        fecha_nueva timestamp(6) not null,
        id bigserial not null,
        sala_anterior_id bigint,
        sala_nueva_id bigint,
        usuario_id bigint not null,
        motivo TEXT,
        primary key (id)
    );

    create table presus.historial_estados_solicitud (
        estado_anterior_id integer,
        estado_nuevo_id integer not null,
        fecha_cambio timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null,
        usuario_id bigint not null,
        comentario TEXT,
        primary key (id)
    );

    create table presus.jornadas (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.lineas_investigacion (
        facultad_id integer,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.miembros_tribunal (
        confirmado boolean not null,
        rol_jurado_id integer not null,
        asignado_en timestamp(6) not null,
        docente_id bigint not null,
        id bigserial not null,
        solicitud_id bigint not null,
        primary key (id),
        unique (solicitud_id, docente_id)
    );

    create table presus.modalidades_titulacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table presus.periodos_academicos (
        activo boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(100) not null,
        primary key (id)
    );

    create table presus.resultados_evaluacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_jurado (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_usuario (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.tipos_evaluador (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.tipos_mensaje (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table actas (
        fecha_generacion date not null,
        firmada boolean not null,
        firmada_presidente boolean not null,
        firmada_tutor boolean not null,
        firmada_vocal1 boolean not null,
        firmada_vocal2 boolean not null,
        fecha_firma_presidente timestamp(6),
        fecha_firma_tutor timestamp(6),
        fecha_firma_vocal1 timestamp(6),
        fecha_firma_vocal2 timestamp(6),
        id bigserial not null,
        solicitud_id bigint not null unique,
        archivo_pdf varchar(255),
        observaciones_acta TEXT,
        primary key (id)
    );

    create table anteproyectos (
        fecha_envio date,
        id bigserial not null,
        solicitud_id bigint unique,
        tamano_bytes bigint,
        estado varchar(30),
        sha256_hash varchar(64),
        archivo_pdf varchar(255),
        observaciones TEXT,
        primary key (id)
    );

    create table criterios_rubrica (
        orden integer not null,
        ponderacion float(53) not null,
        id bigserial not null,
        rubrica_id bigint not null,
        nombre varchar(100) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table cronograma (
        bloque_id integer,
        convocatoria_id integer not null,
        duracion_min integer not null,
        estado_id integer not null,
        numero_intento smallint not null,
        creado_en timestamp(6) not null,
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        sala_id bigint not null,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table docente (
        carga_horaria_semanal integer not null,
        disponible boolean not null,
        facultad_id integer,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        area_especialidad varchar(180),
        primary key (id)
    );

    create table estudiante (
        carrera_id integer not null,
        periodo_ingreso_id integer,
        semestre_actual smallint not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        semestre varchar(30),
        telefono varchar(30),
        expediente_codigo varchar(60) unique,
        carrera varchar(180) not null,
        primary key (id)
    );

    create table evaluaciones (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint unique,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table evaluaciones_criterio (
        escala integer not null,
        nota_obtenida float(53) not null,
        criterio_id bigint not null,
        evaluador_id bigint not null,
        id bigserial not null,
        registrado_en timestamp(6) not null,
        solicitud_id bigint not null,
        observacion_auto TEXT,
        observacion_manual TEXT,
        observaciones TEXT,
        primary key (id),
        unique (evaluador_id, criterio_id)
    );

    create table evaluaciones_jurado (
        nota_jurado float(53) not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        jurado_id bigint not null,
        solicitud_id bigint not null,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table notificaciones (
        leida boolean not null,
        fecha timestamp(6),
        id bigserial not null,
        usuario_id bigint,
        mensaje TEXT,
        primary key (id)
    );

    create table rubricas (
        puntaje_maximo float(53) not null,
        id bigserial not null,
        nombre varchar(120) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table sala (
        capacidad integer not null,
        disponible boolean not null,
        id bigserial not null,
        codigo varchar(40) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table solicitud (
        area_tematica_id integer,
        convocatoria_id integer not null,
        estado_id integer not null,
        linea_investigacion_id integer,
        modalidad_titulacion_id integer not null,
        actualizado_en timestamp(6) not null,
        actualizado_por bigint,
        creado_por bigint,
        estudiante_id bigint not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        suspendido_en timestamp(6),
        titulo_tema varchar(300) not null,
        motivo_suspension TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table tutores (
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null unique,
        estado varchar(20) not null,
        observaciones TEXT,
        primary key (id)
    );

    create table tutoria_fases (
        numero_fase integer not null,
        fecha_aprobacion timestamp(6),
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        tamano_pdf_bytes bigint,
        tutor_id bigint not null,
        estado varchar(30) not null,
        sha256_pdf varchar(64),
        archivo_pdf_estudiante varchar(255),
        primary key (id)
    );

    create table tutoria_mensajes (
        leido boolean not null,
        fase_id bigint not null,
        fecha_envio timestamp(6) not null,
        id bigserial not null,
        remitente_id bigint not null,
        tipo varchar(20) not null,
        contenido TEXT not null,
        primary key (id)
    );

    create table usuarios (
        activo boolean not null,
        rol_id integer not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        apellido varchar(255) not null,
        email varchar(255) not null unique,
        email_notificaciones varchar(255),
        nombre varchar(255) not null,
        password varchar(255) not null,
        rol varchar(255) not null,
        telefono varchar(255),
        primary key (id)
    );

    alter table if exists presus.areas_tematicas 
       add constraint FK89neyi3j42yt914y9dsepvx8g 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists presus.bloques_horarios 
       add constraint FKhimm4vkb8aaamcb8ig77qk8jr 
       foreign key (jornada_id) 
       references presus.jornadas;

    alter table if exists presus.carreras 
       add constraint FKpkbqfnd3xcstklurnni1v7hi8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.convocatorias_titulacion 
       add constraint FKkhjxrhwxttrjg54fosa70k0ib 
       foreign key (periodo_academico_id) 
       references presus.periodos_academicos;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKaqxqt9i1aht1anwbwjtnxkjay 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKdnyk315lc3r3lxpja9ff5aa72 
       foreign key (sala_id) 
       references sala;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK1656v7687m5a006ig2dnxdxlq 
       foreign key (resultado_id) 
       references presus.resultados_evaluacion;

    alter table if exists presus.evaluaciones_finales 
       add constraint FKqr6nw8s42apawhtrjaufmemmk 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK6j0y0jr90cysn9b2xomrn2907 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKdcv3fm9ch7f9otbph1sc0kc56 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.evaluadores 
       add constraint FKf2c67wiobryo5c5us94dxo2nj 
       foreign key (miembro_tribunal_id) 
       references presus.miembros_tribunal;

    alter table if exists presus.evaluadores 
       add constraint FK7lfvwr8cap0mtqx82eypyrfkd 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKf7pg14kvrds8f3splp0a3d9m8 
       foreign key (tipo_evaluador_id) 
       references presus.tipos_evaluador;

    alter table if exists presus.historial_cronograma 
       add constraint FKi3w1x79h0hqgek4qn3a3m2j5x 
       foreign key (cronograma_id) 
       references cronograma;

    alter table if exists presus.historial_cronograma 
       add constraint FKaou7dy35isiktfxl0wvrv24c5 
       foreign key (sala_anterior_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKhlaxapi4vhyntrt7m1eukbvb6 
       foreign key (sala_nueva_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKnjwyynwb33g4jaat7k03korot 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKquuy4n6l595u3n1eesse65lm7 
       foreign key (estado_anterior_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKcduxdoctlihmlrf7jc79hktbr 
       foreign key (estado_nuevo_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK27v25jypoybt045dokcm47yul 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK28v16j834n0mxh44jrkouaard 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.lineas_investigacion 
       add constraint FK6mbdout54e5jy49tpaeqijaa8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.miembros_tribunal 
       add constraint FKrvimgktkif6hr7u3w0l2r345q 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.miembros_tribunal 
       add constraint FKii8qums5v0taxx349emm7th6g 
       foreign key (rol_jurado_id) 
       references presus.roles_jurado;

    alter table if exists presus.miembros_tribunal 
       add constraint FKebkpg7s5whbr9va2yvfaf1act 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists actas 
       add constraint FKbe1mhcpm4hh94m47oxihlkh6i 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists anteproyectos 
       add constraint FKnuplmmjrbs76slhxrt6swwytj 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists criterios_rubrica 
       add constraint FKrwb21y79trk780jwtk34aiqr3 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists cronograma 
       add constraint FKch4phbxqt1j7wck6fh34phj62 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists cronograma 
       add constraint FKbp2d8c5i4pgy0mbhae0f5cj78 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists cronograma 
       add constraint FKbt78p9nbvdowoh0dwisdpnk2n 
       foreign key (estado_id) 
       references presus.estados_cronograma;

    alter table if exists cronograma 
       add constraint FKnkurftcc1qsc7alh7276l5uq1 
       foreign key (sala_id) 
       references sala;

    alter table if exists cronograma 
       add constraint FK7wxxnuex9myk4vf3qbr8nm2qn 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists docente 
       add constraint FKroasnisuah9k11docjg9q46w6 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists docente 
       add constraint FKbs42aumodddav4mosgah3bomi 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists estudiante 
       add constraint FK6mibklpfbmshbwm5ly7t6quc1 
       foreign key (carrera_id) 
       references presus.carreras;

    alter table if exists estudiante 
       add constraint FK665t8l4wpufihhoes8s1938ht 
       foreign key (periodo_ingreso_id) 
       references presus.periodos_academicos;

    alter table if exists estudiante 
       add constraint FKmb0c2sqmehp6spvhm53mej2b7 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists evaluaciones 
       add constraint FKcw8bowlxco293tni77pshk0un 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists evaluaciones 
       add constraint FK53hknbr7ctsod58a57sbk99j9 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_criterio 
       add constraint FK704dbpt9dfb9cc4q2frdk1e59 
       foreign key (criterio_id) 
       references criterios_rubrica;

    alter table if exists evaluaciones_criterio 
       add constraint FKdsk8q9dykx4cndxxmyxg679fc 
       foreign key (evaluador_id) 
       references presus.evaluadores;

    alter table if exists evaluaciones_criterio 
       add constraint FKiwxwbpykr3vo23lxeimiwmfji 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_jurado 
       add constraint FK53wpgafopnaoqe0cge5mi09g8 
       foreign key (jurado_id) 
       references presus.miembros_tribunal;

    alter table if exists evaluaciones_jurado 
       add constraint FK3m5avtbjkv8okijdpvnba6br8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists notificaciones 
       add constraint FK1mxbjb81ft61gwlh0kabubndc 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK5lihp07xom3g6aiv6aid1mqoy 
       foreign key (actualizado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FKkocwlitlopkh7puo52h9tncxj 
       foreign key (area_tematica_id) 
       references presus.areas_tematicas;

    alter table if exists solicitud 
       add constraint FK4o0t4min6fnjh6wtewgwetdsc 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists solicitud 
       add constraint FKbslas51apjrlk1sspwjxcahpd 
       foreign key (creado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK3kdfcybjca99ian0k5g1mhhoq 
       foreign key (estado_id) 
       references presus.estados_solicitud;

    alter table if exists solicitud 
       add constraint FK1gfsheb54hb4313592ynmr5u4 
       foreign key (estudiante_id) 
       references estudiante;

    alter table if exists solicitud 
       add constraint FKg1jysw6105nj3u40g1ahsx14l 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists solicitud 
       add constraint FKaxmn3drihjstewcid9a1wjuw9 
       foreign key (modalidad_titulacion_id) 
       references presus.modalidades_titulacion;

    alter table if exists tutores 
       add constraint FKb2xb48y98w51rrxljckb63d92 
       foreign key (docente_id) 
       references docente;

    alter table if exists tutores 
       add constraint FKpva6fxtkmtc7e8y8qh3ci1jg8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists tutoria_fases 
       add constraint FKennbyt8lrhckfi7fwkpw8qgfm 
       foreign key (tutor_id) 
       references tutores;

    alter table if exists tutoria_mensajes 
       add constraint FK6otp7q57xutoo6yhs7m5vkn19 
       foreign key (fase_id) 
       references tutoria_fases;

    alter table if exists tutoria_mensajes 
       add constraint FKj3p4s6quhocjaojcdvw2t8ag2 
       foreign key (remitente_id) 
       references usuarios;

    alter table if exists usuarios 
       add constraint FKku0it797v3701ntswwvl95ei 
       foreign key (rol_id) 
       references presus.roles_usuario;

    create table presus.areas_tematicas (
        id serial not null,
        linea_investigacion_id integer not null,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.bloques_horarios (
        hora_fin time(6) not null,
        hora_inicio time(6) not null,
        id serial not null,
        jornada_id integer not null,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.carreras (
        facultad_id integer not null,
        id serial not null,
        codigo varchar(20) not null unique,
        modalidad_estudio varchar(40),
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.convocatorias_titulacion (
        activa boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        periodo_academico_id integer not null,
        codigo varchar(30) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.disponibilidad_sala (
        bloque_id integer not null,
        disponible boolean not null,
        fecha date not null,
        id bigserial not null,
        sala_id bigint not null,
        motivo varchar(200),
        primary key (id)
    );

    create table presus.estados_cronograma (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_proceso (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_solicitud (
        id serial not null,
        orden smallint not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.evaluaciones_finales (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado_promedio float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        resultado_id integer,
        fecha_calculo timestamp(6) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint not null unique,
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table presus.evaluadores (
        peso float(53) not null,
        tipo_evaluador_id integer not null,
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        miembro_tribunal_id bigint,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table presus.facultades (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.historial_cronograma (
        cronograma_id bigint not null,
        fecha_anterior timestamp(6) not null,
        fecha_cambio timestamp(6) not null,
        fecha_nueva timestamp(6) not null,
        id bigserial not null,
        sala_anterior_id bigint,
        sala_nueva_id bigint,
        usuario_id bigint not null,
        motivo TEXT,
        primary key (id)
    );

    create table presus.historial_estados_solicitud (
        estado_anterior_id integer,
        estado_nuevo_id integer not null,
        fecha_cambio timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null,
        usuario_id bigint not null,
        comentario TEXT,
        primary key (id)
    );

    create table presus.jornadas (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.lineas_investigacion (
        facultad_id integer,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.miembros_tribunal (
        confirmado boolean not null,
        rol_jurado_id integer not null,
        asignado_en timestamp(6) not null,
        docente_id bigint not null,
        id bigserial not null,
        solicitud_id bigint not null,
        primary key (id),
        unique (solicitud_id, docente_id)
    );

    create table presus.modalidades_titulacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table presus.periodos_academicos (
        activo boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(100) not null,
        primary key (id)
    );

    create table presus.resultados_evaluacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_jurado (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_usuario (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.tipos_evaluador (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.tipos_mensaje (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table actas (
        fecha_generacion date not null,
        firmada boolean not null,
        firmada_presidente boolean not null,
        firmada_tutor boolean not null,
        firmada_vocal1 boolean not null,
        firmada_vocal2 boolean not null,
        fecha_firma_presidente timestamp(6),
        fecha_firma_tutor timestamp(6),
        fecha_firma_vocal1 timestamp(6),
        fecha_firma_vocal2 timestamp(6),
        id bigserial not null,
        solicitud_id bigint not null unique,
        archivo_pdf varchar(255),
        observaciones_acta TEXT,
        primary key (id)
    );

    create table anteproyectos (
        fecha_envio date,
        id bigserial not null,
        solicitud_id bigint unique,
        tamano_bytes bigint,
        estado varchar(30),
        sha256_hash varchar(64),
        archivo_pdf varchar(255),
        observaciones TEXT,
        primary key (id)
    );

    create table criterios_rubrica (
        orden integer not null,
        ponderacion float(53) not null,
        id bigserial not null,
        rubrica_id bigint not null,
        nombre varchar(100) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table cronograma (
        bloque_id integer,
        convocatoria_id integer not null,
        duracion_min integer not null,
        estado_id integer not null,
        numero_intento smallint not null,
        creado_en timestamp(6) not null,
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        sala_id bigint not null,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table docente (
        carga_horaria_semanal integer not null,
        disponible boolean not null,
        facultad_id integer,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        area_especialidad varchar(180),
        primary key (id)
    );

    create table estudiante (
        carrera_id integer not null,
        periodo_ingreso_id integer,
        semestre_actual smallint not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        semestre varchar(30),
        telefono varchar(30),
        expediente_codigo varchar(60) unique,
        carrera varchar(180) not null,
        primary key (id)
    );

    create table evaluaciones (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint unique,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table evaluaciones_criterio (
        escala integer not null,
        nota_obtenida float(53) not null,
        criterio_id bigint not null,
        evaluador_id bigint not null,
        id bigserial not null,
        registrado_en timestamp(6) not null,
        solicitud_id bigint not null,
        observacion_auto TEXT,
        observacion_manual TEXT,
        observaciones TEXT,
        primary key (id),
        unique (evaluador_id, criterio_id)
    );

    create table evaluaciones_jurado (
        nota_jurado float(53) not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        jurado_id bigint not null,
        solicitud_id bigint not null,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table notificaciones (
        leida boolean not null,
        fecha timestamp(6),
        id bigserial not null,
        usuario_id bigint,
        mensaje TEXT,
        primary key (id)
    );

    create table rubricas (
        puntaje_maximo float(53) not null,
        id bigserial not null,
        nombre varchar(120) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table sala (
        capacidad integer not null,
        disponible boolean not null,
        id bigserial not null,
        codigo varchar(40) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table solicitud (
        area_tematica_id integer,
        convocatoria_id integer not null,
        estado_id integer not null,
        linea_investigacion_id integer,
        modalidad_titulacion_id integer not null,
        actualizado_en timestamp(6) not null,
        actualizado_por bigint,
        creado_por bigint,
        estudiante_id bigint not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        suspendido_en timestamp(6),
        titulo_tema varchar(300) not null,
        motivo_suspension TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table tutores (
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null unique,
        estado varchar(20) not null,
        observaciones TEXT,
        primary key (id)
    );

    create table tutoria_fases (
        numero_fase integer not null,
        fecha_aprobacion timestamp(6),
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        tamano_pdf_bytes bigint,
        tutor_id bigint not null,
        estado varchar(30) not null,
        sha256_pdf varchar(64),
        archivo_pdf_estudiante varchar(255),
        primary key (id)
    );

    create table tutoria_mensajes (
        leido boolean not null,
        fase_id bigint not null,
        fecha_envio timestamp(6) not null,
        id bigserial not null,
        remitente_id bigint not null,
        tipo varchar(20) not null,
        contenido TEXT not null,
        primary key (id)
    );

    create table usuarios (
        activo boolean not null,
        rol_id integer not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        apellido varchar(255) not null,
        email varchar(255) not null unique,
        email_notificaciones varchar(255),
        nombre varchar(255) not null,
        password varchar(255) not null,
        rol varchar(255) not null,
        telefono varchar(255),
        primary key (id)
    );

    alter table if exists presus.areas_tematicas 
       add constraint FK89neyi3j42yt914y9dsepvx8g 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists presus.bloques_horarios 
       add constraint FKhimm4vkb8aaamcb8ig77qk8jr 
       foreign key (jornada_id) 
       references presus.jornadas;

    alter table if exists presus.carreras 
       add constraint FKpkbqfnd3xcstklurnni1v7hi8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.convocatorias_titulacion 
       add constraint FKkhjxrhwxttrjg54fosa70k0ib 
       foreign key (periodo_academico_id) 
       references presus.periodos_academicos;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKaqxqt9i1aht1anwbwjtnxkjay 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKdnyk315lc3r3lxpja9ff5aa72 
       foreign key (sala_id) 
       references sala;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK1656v7687m5a006ig2dnxdxlq 
       foreign key (resultado_id) 
       references presus.resultados_evaluacion;

    alter table if exists presus.evaluaciones_finales 
       add constraint FKqr6nw8s42apawhtrjaufmemmk 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK6j0y0jr90cysn9b2xomrn2907 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKdcv3fm9ch7f9otbph1sc0kc56 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.evaluadores 
       add constraint FKf2c67wiobryo5c5us94dxo2nj 
       foreign key (miembro_tribunal_id) 
       references presus.miembros_tribunal;

    alter table if exists presus.evaluadores 
       add constraint FK7lfvwr8cap0mtqx82eypyrfkd 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKf7pg14kvrds8f3splp0a3d9m8 
       foreign key (tipo_evaluador_id) 
       references presus.tipos_evaluador;

    alter table if exists presus.historial_cronograma 
       add constraint FKi3w1x79h0hqgek4qn3a3m2j5x 
       foreign key (cronograma_id) 
       references cronograma;

    alter table if exists presus.historial_cronograma 
       add constraint FKaou7dy35isiktfxl0wvrv24c5 
       foreign key (sala_anterior_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKhlaxapi4vhyntrt7m1eukbvb6 
       foreign key (sala_nueva_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKnjwyynwb33g4jaat7k03korot 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKquuy4n6l595u3n1eesse65lm7 
       foreign key (estado_anterior_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKcduxdoctlihmlrf7jc79hktbr 
       foreign key (estado_nuevo_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK27v25jypoybt045dokcm47yul 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK28v16j834n0mxh44jrkouaard 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.lineas_investigacion 
       add constraint FK6mbdout54e5jy49tpaeqijaa8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.miembros_tribunal 
       add constraint FKrvimgktkif6hr7u3w0l2r345q 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.miembros_tribunal 
       add constraint FKii8qums5v0taxx349emm7th6g 
       foreign key (rol_jurado_id) 
       references presus.roles_jurado;

    alter table if exists presus.miembros_tribunal 
       add constraint FKebkpg7s5whbr9va2yvfaf1act 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists actas 
       add constraint FKbe1mhcpm4hh94m47oxihlkh6i 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists anteproyectos 
       add constraint FKnuplmmjrbs76slhxrt6swwytj 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists criterios_rubrica 
       add constraint FKrwb21y79trk780jwtk34aiqr3 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists cronograma 
       add constraint FKch4phbxqt1j7wck6fh34phj62 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists cronograma 
       add constraint FKbp2d8c5i4pgy0mbhae0f5cj78 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists cronograma 
       add constraint FKbt78p9nbvdowoh0dwisdpnk2n 
       foreign key (estado_id) 
       references presus.estados_cronograma;

    alter table if exists cronograma 
       add constraint FKnkurftcc1qsc7alh7276l5uq1 
       foreign key (sala_id) 
       references sala;

    alter table if exists cronograma 
       add constraint FK7wxxnuex9myk4vf3qbr8nm2qn 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists docente 
       add constraint FKroasnisuah9k11docjg9q46w6 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists docente 
       add constraint FKbs42aumodddav4mosgah3bomi 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists estudiante 
       add constraint FK6mibklpfbmshbwm5ly7t6quc1 
       foreign key (carrera_id) 
       references presus.carreras;

    alter table if exists estudiante 
       add constraint FK665t8l4wpufihhoes8s1938ht 
       foreign key (periodo_ingreso_id) 
       references presus.periodos_academicos;

    alter table if exists estudiante 
       add constraint FKmb0c2sqmehp6spvhm53mej2b7 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists evaluaciones 
       add constraint FKcw8bowlxco293tni77pshk0un 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists evaluaciones 
       add constraint FK53hknbr7ctsod58a57sbk99j9 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_criterio 
       add constraint FK704dbpt9dfb9cc4q2frdk1e59 
       foreign key (criterio_id) 
       references criterios_rubrica;

    alter table if exists evaluaciones_criterio 
       add constraint FKdsk8q9dykx4cndxxmyxg679fc 
       foreign key (evaluador_id) 
       references presus.evaluadores;

    alter table if exists evaluaciones_criterio 
       add constraint FKiwxwbpykr3vo23lxeimiwmfji 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_jurado 
       add constraint FK53wpgafopnaoqe0cge5mi09g8 
       foreign key (jurado_id) 
       references presus.miembros_tribunal;

    alter table if exists evaluaciones_jurado 
       add constraint FK3m5avtbjkv8okijdpvnba6br8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists notificaciones 
       add constraint FK1mxbjb81ft61gwlh0kabubndc 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK5lihp07xom3g6aiv6aid1mqoy 
       foreign key (actualizado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FKkocwlitlopkh7puo52h9tncxj 
       foreign key (area_tematica_id) 
       references presus.areas_tematicas;

    alter table if exists solicitud 
       add constraint FK4o0t4min6fnjh6wtewgwetdsc 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists solicitud 
       add constraint FKbslas51apjrlk1sspwjxcahpd 
       foreign key (creado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK3kdfcybjca99ian0k5g1mhhoq 
       foreign key (estado_id) 
       references presus.estados_solicitud;

    alter table if exists solicitud 
       add constraint FK1gfsheb54hb4313592ynmr5u4 
       foreign key (estudiante_id) 
       references estudiante;

    alter table if exists solicitud 
       add constraint FKg1jysw6105nj3u40g1ahsx14l 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists solicitud 
       add constraint FKaxmn3drihjstewcid9a1wjuw9 
       foreign key (modalidad_titulacion_id) 
       references presus.modalidades_titulacion;

    alter table if exists tutores 
       add constraint FKb2xb48y98w51rrxljckb63d92 
       foreign key (docente_id) 
       references docente;

    alter table if exists tutores 
       add constraint FKpva6fxtkmtc7e8y8qh3ci1jg8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists tutoria_fases 
       add constraint FKennbyt8lrhckfi7fwkpw8qgfm 
       foreign key (tutor_id) 
       references tutores;

    alter table if exists tutoria_mensajes 
       add constraint FK6otp7q57xutoo6yhs7m5vkn19 
       foreign key (fase_id) 
       references tutoria_fases;

    alter table if exists tutoria_mensajes 
       add constraint FKj3p4s6quhocjaojcdvw2t8ag2 
       foreign key (remitente_id) 
       references usuarios;

    alter table if exists usuarios 
       add constraint FKku0it797v3701ntswwvl95ei 
       foreign key (rol_id) 
       references presus.roles_usuario;

    create table presus.areas_tematicas (
        id serial not null,
        linea_investigacion_id integer not null,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.bloques_horarios (
        hora_fin time(6) not null,
        hora_inicio time(6) not null,
        id serial not null,
        jornada_id integer not null,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.carreras (
        facultad_id integer not null,
        id serial not null,
        codigo varchar(20) not null unique,
        modalidad_estudio varchar(40),
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.convocatorias_titulacion (
        activa boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        periodo_academico_id integer not null,
        codigo varchar(30) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.disponibilidad_sala (
        bloque_id integer not null,
        disponible boolean not null,
        fecha date not null,
        id bigserial not null,
        sala_id bigint not null,
        motivo varchar(200),
        primary key (id)
    );

    create table presus.estados_cronograma (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_proceso (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_solicitud (
        id serial not null,
        orden smallint not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.evaluaciones_finales (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado_promedio float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        resultado_id integer,
        fecha_calculo timestamp(6) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint not null unique,
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table presus.evaluadores (
        peso float(53) not null,
        tipo_evaluador_id integer not null,
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        miembro_tribunal_id bigint,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table presus.facultades (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.historial_cronograma (
        cronograma_id bigint not null,
        fecha_anterior timestamp(6) not null,
        fecha_cambio timestamp(6) not null,
        fecha_nueva timestamp(6) not null,
        id bigserial not null,
        sala_anterior_id bigint,
        sala_nueva_id bigint,
        usuario_id bigint not null,
        motivo TEXT,
        primary key (id)
    );

    create table presus.historial_estados_solicitud (
        estado_anterior_id integer,
        estado_nuevo_id integer not null,
        fecha_cambio timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null,
        usuario_id bigint not null,
        comentario TEXT,
        primary key (id)
    );

    create table presus.jornadas (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.lineas_investigacion (
        facultad_id integer,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.miembros_tribunal (
        confirmado boolean not null,
        rol_jurado_id integer not null,
        asignado_en timestamp(6) not null,
        docente_id bigint not null,
        id bigserial not null,
        solicitud_id bigint not null,
        primary key (id),
        unique (solicitud_id, docente_id)
    );

    create table presus.modalidades_titulacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table presus.periodos_academicos (
        activo boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(100) not null,
        primary key (id)
    );

    create table presus.resultados_evaluacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_jurado (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_usuario (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.tipos_evaluador (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.tipos_mensaje (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table actas (
        fecha_generacion date not null,
        firmada boolean not null,
        firmada_presidente boolean not null,
        firmada_tutor boolean not null,
        firmada_vocal1 boolean not null,
        firmada_vocal2 boolean not null,
        fecha_firma_presidente timestamp(6),
        fecha_firma_tutor timestamp(6),
        fecha_firma_vocal1 timestamp(6),
        fecha_firma_vocal2 timestamp(6),
        id bigserial not null,
        solicitud_id bigint not null unique,
        archivo_pdf varchar(255),
        observaciones_acta TEXT,
        primary key (id)
    );

    create table anteproyectos (
        fecha_envio date,
        id bigserial not null,
        solicitud_id bigint unique,
        tamano_bytes bigint,
        estado varchar(30),
        sha256_hash varchar(64),
        archivo_pdf varchar(255),
        observaciones TEXT,
        primary key (id)
    );

    create table criterios_rubrica (
        orden integer not null,
        ponderacion float(53) not null,
        id bigserial not null,
        rubrica_id bigint not null,
        nombre varchar(100) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table cronograma (
        bloque_id integer,
        convocatoria_id integer not null,
        duracion_min integer not null,
        estado_id integer not null,
        numero_intento smallint not null,
        creado_en timestamp(6) not null,
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        sala_id bigint not null,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table docente (
        carga_horaria_semanal integer not null,
        disponible boolean not null,
        facultad_id integer,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        area_especialidad varchar(180),
        primary key (id)
    );

    create table estudiante (
        carrera_id integer not null,
        periodo_ingreso_id integer,
        semestre_actual smallint not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        semestre varchar(30),
        telefono varchar(30),
        expediente_codigo varchar(60) unique,
        carrera varchar(180) not null,
        primary key (id)
    );

    create table evaluaciones (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint unique,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table evaluaciones_criterio (
        escala integer not null,
        nota_obtenida float(53) not null,
        criterio_id bigint not null,
        evaluador_id bigint not null,
        id bigserial not null,
        registrado_en timestamp(6) not null,
        solicitud_id bigint not null,
        observacion_auto TEXT,
        observacion_manual TEXT,
        observaciones TEXT,
        primary key (id),
        unique (evaluador_id, criterio_id)
    );

    create table evaluaciones_jurado (
        nota_jurado float(53) not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        jurado_id bigint not null,
        solicitud_id bigint not null,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table notificaciones (
        leida boolean not null,
        fecha timestamp(6),
        id bigserial not null,
        usuario_id bigint,
        mensaje TEXT,
        primary key (id)
    );

    create table rubricas (
        puntaje_maximo float(53) not null,
        id bigserial not null,
        nombre varchar(120) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table sala (
        capacidad integer not null,
        disponible boolean not null,
        id bigserial not null,
        codigo varchar(40) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table solicitud (
        area_tematica_id integer,
        convocatoria_id integer not null,
        estado_id integer not null,
        linea_investigacion_id integer,
        modalidad_titulacion_id integer not null,
        actualizado_en timestamp(6) not null,
        actualizado_por bigint,
        creado_por bigint,
        estudiante_id bigint not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        suspendido_en timestamp(6),
        titulo_tema varchar(300) not null,
        motivo_suspension TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table tutores (
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null unique,
        estado varchar(20) not null,
        observaciones TEXT,
        primary key (id)
    );

    create table tutoria_fases (
        numero_fase integer not null,
        fecha_aprobacion timestamp(6),
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        tamano_pdf_bytes bigint,
        tutor_id bigint not null,
        estado varchar(30) not null,
        sha256_pdf varchar(64),
        archivo_pdf_estudiante varchar(255),
        primary key (id)
    );

    create table tutoria_mensajes (
        leido boolean not null,
        fase_id bigint not null,
        fecha_envio timestamp(6) not null,
        id bigserial not null,
        remitente_id bigint not null,
        tipo varchar(20) not null,
        contenido TEXT not null,
        primary key (id)
    );

    create table usuarios (
        activo boolean not null,
        rol_id integer not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        apellido varchar(255) not null,
        email varchar(255) not null unique,
        email_notificaciones varchar(255),
        nombre varchar(255) not null,
        password varchar(255) not null,
        rol varchar(255) not null,
        telefono varchar(255),
        primary key (id)
    );

    alter table if exists presus.areas_tematicas 
       add constraint FK89neyi3j42yt914y9dsepvx8g 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists presus.bloques_horarios 
       add constraint FKhimm4vkb8aaamcb8ig77qk8jr 
       foreign key (jornada_id) 
       references presus.jornadas;

    alter table if exists presus.carreras 
       add constraint FKpkbqfnd3xcstklurnni1v7hi8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.convocatorias_titulacion 
       add constraint FKkhjxrhwxttrjg54fosa70k0ib 
       foreign key (periodo_academico_id) 
       references presus.periodos_academicos;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKaqxqt9i1aht1anwbwjtnxkjay 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKdnyk315lc3r3lxpja9ff5aa72 
       foreign key (sala_id) 
       references sala;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK1656v7687m5a006ig2dnxdxlq 
       foreign key (resultado_id) 
       references presus.resultados_evaluacion;

    alter table if exists presus.evaluaciones_finales 
       add constraint FKqr6nw8s42apawhtrjaufmemmk 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK6j0y0jr90cysn9b2xomrn2907 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKdcv3fm9ch7f9otbph1sc0kc56 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.evaluadores 
       add constraint FKf2c67wiobryo5c5us94dxo2nj 
       foreign key (miembro_tribunal_id) 
       references presus.miembros_tribunal;

    alter table if exists presus.evaluadores 
       add constraint FK7lfvwr8cap0mtqx82eypyrfkd 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKf7pg14kvrds8f3splp0a3d9m8 
       foreign key (tipo_evaluador_id) 
       references presus.tipos_evaluador;

    alter table if exists presus.historial_cronograma 
       add constraint FKi3w1x79h0hqgek4qn3a3m2j5x 
       foreign key (cronograma_id) 
       references cronograma;

    alter table if exists presus.historial_cronograma 
       add constraint FKaou7dy35isiktfxl0wvrv24c5 
       foreign key (sala_anterior_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKhlaxapi4vhyntrt7m1eukbvb6 
       foreign key (sala_nueva_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKnjwyynwb33g4jaat7k03korot 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKquuy4n6l595u3n1eesse65lm7 
       foreign key (estado_anterior_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKcduxdoctlihmlrf7jc79hktbr 
       foreign key (estado_nuevo_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK27v25jypoybt045dokcm47yul 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK28v16j834n0mxh44jrkouaard 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.lineas_investigacion 
       add constraint FK6mbdout54e5jy49tpaeqijaa8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.miembros_tribunal 
       add constraint FKrvimgktkif6hr7u3w0l2r345q 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.miembros_tribunal 
       add constraint FKii8qums5v0taxx349emm7th6g 
       foreign key (rol_jurado_id) 
       references presus.roles_jurado;

    alter table if exists presus.miembros_tribunal 
       add constraint FKebkpg7s5whbr9va2yvfaf1act 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists actas 
       add constraint FKbe1mhcpm4hh94m47oxihlkh6i 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists anteproyectos 
       add constraint FKnuplmmjrbs76slhxrt6swwytj 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists criterios_rubrica 
       add constraint FKrwb21y79trk780jwtk34aiqr3 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists cronograma 
       add constraint FKch4phbxqt1j7wck6fh34phj62 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists cronograma 
       add constraint FKbp2d8c5i4pgy0mbhae0f5cj78 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists cronograma 
       add constraint FKbt78p9nbvdowoh0dwisdpnk2n 
       foreign key (estado_id) 
       references presus.estados_cronograma;

    alter table if exists cronograma 
       add constraint FKnkurftcc1qsc7alh7276l5uq1 
       foreign key (sala_id) 
       references sala;

    alter table if exists cronograma 
       add constraint FK7wxxnuex9myk4vf3qbr8nm2qn 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists docente 
       add constraint FKroasnisuah9k11docjg9q46w6 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists docente 
       add constraint FKbs42aumodddav4mosgah3bomi 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists estudiante 
       add constraint FK6mibklpfbmshbwm5ly7t6quc1 
       foreign key (carrera_id) 
       references presus.carreras;

    alter table if exists estudiante 
       add constraint FK665t8l4wpufihhoes8s1938ht 
       foreign key (periodo_ingreso_id) 
       references presus.periodos_academicos;

    alter table if exists estudiante 
       add constraint FKmb0c2sqmehp6spvhm53mej2b7 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists evaluaciones 
       add constraint FKcw8bowlxco293tni77pshk0un 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists evaluaciones 
       add constraint FK53hknbr7ctsod58a57sbk99j9 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_criterio 
       add constraint FK704dbpt9dfb9cc4q2frdk1e59 
       foreign key (criterio_id) 
       references criterios_rubrica;

    alter table if exists evaluaciones_criterio 
       add constraint FKdsk8q9dykx4cndxxmyxg679fc 
       foreign key (evaluador_id) 
       references presus.evaluadores;

    alter table if exists evaluaciones_criterio 
       add constraint FKiwxwbpykr3vo23lxeimiwmfji 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_jurado 
       add constraint FK53wpgafopnaoqe0cge5mi09g8 
       foreign key (jurado_id) 
       references presus.miembros_tribunal;

    alter table if exists evaluaciones_jurado 
       add constraint FK3m5avtbjkv8okijdpvnba6br8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists notificaciones 
       add constraint FK1mxbjb81ft61gwlh0kabubndc 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK5lihp07xom3g6aiv6aid1mqoy 
       foreign key (actualizado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FKkocwlitlopkh7puo52h9tncxj 
       foreign key (area_tematica_id) 
       references presus.areas_tematicas;

    alter table if exists solicitud 
       add constraint FK4o0t4min6fnjh6wtewgwetdsc 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists solicitud 
       add constraint FKbslas51apjrlk1sspwjxcahpd 
       foreign key (creado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK3kdfcybjca99ian0k5g1mhhoq 
       foreign key (estado_id) 
       references presus.estados_solicitud;

    alter table if exists solicitud 
       add constraint FK1gfsheb54hb4313592ynmr5u4 
       foreign key (estudiante_id) 
       references estudiante;

    alter table if exists solicitud 
       add constraint FKg1jysw6105nj3u40g1ahsx14l 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists solicitud 
       add constraint FKaxmn3drihjstewcid9a1wjuw9 
       foreign key (modalidad_titulacion_id) 
       references presus.modalidades_titulacion;

    alter table if exists tutores 
       add constraint FKb2xb48y98w51rrxljckb63d92 
       foreign key (docente_id) 
       references docente;

    alter table if exists tutores 
       add constraint FKpva6fxtkmtc7e8y8qh3ci1jg8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists tutoria_fases 
       add constraint FKennbyt8lrhckfi7fwkpw8qgfm 
       foreign key (tutor_id) 
       references tutores;

    alter table if exists tutoria_mensajes 
       add constraint FK6otp7q57xutoo6yhs7m5vkn19 
       foreign key (fase_id) 
       references tutoria_fases;

    alter table if exists tutoria_mensajes 
       add constraint FKj3p4s6quhocjaojcdvw2t8ag2 
       foreign key (remitente_id) 
       references usuarios;

    alter table if exists usuarios 
       add constraint FKku0it797v3701ntswwvl95ei 
       foreign key (rol_id) 
       references presus.roles_usuario;

    create table presus.areas_tematicas (
        id serial not null,
        linea_investigacion_id integer not null,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.bloques_horarios (
        hora_fin time(6) not null,
        hora_inicio time(6) not null,
        id serial not null,
        jornada_id integer not null,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.carreras (
        facultad_id integer not null,
        id serial not null,
        codigo varchar(20) not null unique,
        modalidad_estudio varchar(40),
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.convocatorias_titulacion (
        activa boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        periodo_academico_id integer not null,
        codigo varchar(30) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.disponibilidad_sala (
        bloque_id integer not null,
        disponible boolean not null,
        fecha date not null,
        id bigserial not null,
        sala_id bigint not null,
        motivo varchar(200),
        primary key (id)
    );

    create table presus.estados_cronograma (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_proceso (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_solicitud (
        id serial not null,
        orden smallint not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.evaluaciones_finales (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado_promedio float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        resultado_id integer,
        fecha_calculo timestamp(6) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint not null unique,
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table presus.evaluadores (
        peso float(53) not null,
        tipo_evaluador_id integer not null,
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        miembro_tribunal_id bigint,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table presus.facultades (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.historial_cronograma (
        cronograma_id bigint not null,
        fecha_anterior timestamp(6) not null,
        fecha_cambio timestamp(6) not null,
        fecha_nueva timestamp(6) not null,
        id bigserial not null,
        sala_anterior_id bigint,
        sala_nueva_id bigint,
        usuario_id bigint not null,
        motivo TEXT,
        primary key (id)
    );

    create table presus.historial_estados_solicitud (
        estado_anterior_id integer,
        estado_nuevo_id integer not null,
        fecha_cambio timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null,
        usuario_id bigint not null,
        comentario TEXT,
        primary key (id)
    );

    create table presus.jornadas (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.lineas_investigacion (
        facultad_id integer,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.miembros_tribunal (
        confirmado boolean not null,
        rol_jurado_id integer not null,
        asignado_en timestamp(6) not null,
        docente_id bigint not null,
        id bigserial not null,
        solicitud_id bigint not null,
        primary key (id),
        unique (solicitud_id, docente_id)
    );

    create table presus.modalidades_titulacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table presus.periodos_academicos (
        activo boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(100) not null,
        primary key (id)
    );

    create table presus.resultados_evaluacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_jurado (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_usuario (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.tipos_evaluador (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.tipos_mensaje (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table actas (
        fecha_generacion date not null,
        firmada boolean not null,
        firmada_presidente boolean not null,
        firmada_tutor boolean not null,
        firmada_vocal1 boolean not null,
        firmada_vocal2 boolean not null,
        fecha_firma_presidente timestamp(6),
        fecha_firma_tutor timestamp(6),
        fecha_firma_vocal1 timestamp(6),
        fecha_firma_vocal2 timestamp(6),
        id bigserial not null,
        solicitud_id bigint not null unique,
        archivo_pdf varchar(255),
        observaciones_acta TEXT,
        primary key (id)
    );

    create table anteproyectos (
        fecha_envio date,
        id bigserial not null,
        solicitud_id bigint unique,
        tamano_bytes bigint,
        estado varchar(30),
        sha256_hash varchar(64),
        archivo_pdf varchar(255),
        observaciones TEXT,
        primary key (id)
    );

    create table criterios_rubrica (
        orden integer not null,
        ponderacion float(53) not null,
        id bigserial not null,
        rubrica_id bigint not null,
        nombre varchar(100) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table cronograma (
        bloque_id integer,
        convocatoria_id integer not null,
        duracion_min integer not null,
        estado_id integer not null,
        numero_intento smallint not null,
        creado_en timestamp(6) not null,
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        sala_id bigint not null,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table docente (
        carga_horaria_semanal integer not null,
        disponible boolean not null,
        facultad_id integer,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        area_especialidad varchar(180),
        primary key (id)
    );

    create table estudiante (
        carrera_id integer not null,
        periodo_ingreso_id integer,
        semestre_actual smallint not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        semestre varchar(30),
        telefono varchar(30),
        expediente_codigo varchar(60) unique,
        carrera varchar(180) not null,
        primary key (id)
    );

    create table evaluaciones (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint unique,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table evaluaciones_criterio (
        escala integer not null,
        nota_obtenida float(53) not null,
        criterio_id bigint not null,
        evaluador_id bigint not null,
        id bigserial not null,
        registrado_en timestamp(6) not null,
        solicitud_id bigint not null,
        observacion_auto TEXT,
        observacion_manual TEXT,
        observaciones TEXT,
        primary key (id),
        unique (evaluador_id, criterio_id)
    );

    create table evaluaciones_jurado (
        nota_jurado float(53) not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        jurado_id bigint not null,
        solicitud_id bigint not null,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table notificaciones (
        leida boolean not null,
        fecha timestamp(6),
        id bigserial not null,
        usuario_id bigint,
        mensaje TEXT,
        primary key (id)
    );

    create table rubricas (
        puntaje_maximo float(53) not null,
        id bigserial not null,
        nombre varchar(120) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table sala (
        capacidad integer not null,
        disponible boolean not null,
        id bigserial not null,
        codigo varchar(40) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table solicitud (
        area_tematica_id integer,
        convocatoria_id integer not null,
        estado_id integer not null,
        linea_investigacion_id integer,
        modalidad_titulacion_id integer not null,
        actualizado_en timestamp(6) not null,
        actualizado_por bigint,
        creado_por bigint,
        estudiante_id bigint not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        suspendido_en timestamp(6),
        titulo_tema varchar(300) not null,
        motivo_suspension TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table tutores (
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null unique,
        estado varchar(20) not null,
        observaciones TEXT,
        primary key (id)
    );

    create table tutoria_fases (
        numero_fase integer not null,
        fecha_aprobacion timestamp(6),
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        tamano_pdf_bytes bigint,
        tutor_id bigint not null,
        estado varchar(30) not null,
        sha256_pdf varchar(64),
        archivo_pdf_estudiante varchar(255),
        primary key (id)
    );

    create table tutoria_mensajes (
        leido boolean not null,
        fase_id bigint not null,
        fecha_envio timestamp(6) not null,
        id bigserial not null,
        remitente_id bigint not null,
        tipo varchar(20) not null,
        contenido TEXT not null,
        primary key (id)
    );

    create table usuarios (
        activo boolean not null,
        rol_id integer not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        apellido varchar(255) not null,
        email varchar(255) not null unique,
        email_notificaciones varchar(255),
        nombre varchar(255) not null,
        password varchar(255) not null,
        rol varchar(255) not null,
        telefono varchar(255),
        primary key (id)
    );

    alter table if exists presus.areas_tematicas 
       add constraint FK89neyi3j42yt914y9dsepvx8g 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists presus.bloques_horarios 
       add constraint FKhimm4vkb8aaamcb8ig77qk8jr 
       foreign key (jornada_id) 
       references presus.jornadas;

    alter table if exists presus.carreras 
       add constraint FKpkbqfnd3xcstklurnni1v7hi8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.convocatorias_titulacion 
       add constraint FKkhjxrhwxttrjg54fosa70k0ib 
       foreign key (periodo_academico_id) 
       references presus.periodos_academicos;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKaqxqt9i1aht1anwbwjtnxkjay 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKdnyk315lc3r3lxpja9ff5aa72 
       foreign key (sala_id) 
       references sala;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK1656v7687m5a006ig2dnxdxlq 
       foreign key (resultado_id) 
       references presus.resultados_evaluacion;

    alter table if exists presus.evaluaciones_finales 
       add constraint FKqr6nw8s42apawhtrjaufmemmk 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK6j0y0jr90cysn9b2xomrn2907 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKdcv3fm9ch7f9otbph1sc0kc56 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.evaluadores 
       add constraint FKf2c67wiobryo5c5us94dxo2nj 
       foreign key (miembro_tribunal_id) 
       references presus.miembros_tribunal;

    alter table if exists presus.evaluadores 
       add constraint FK7lfvwr8cap0mtqx82eypyrfkd 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKf7pg14kvrds8f3splp0a3d9m8 
       foreign key (tipo_evaluador_id) 
       references presus.tipos_evaluador;

    alter table if exists presus.historial_cronograma 
       add constraint FKi3w1x79h0hqgek4qn3a3m2j5x 
       foreign key (cronograma_id) 
       references cronograma;

    alter table if exists presus.historial_cronograma 
       add constraint FKaou7dy35isiktfxl0wvrv24c5 
       foreign key (sala_anterior_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKhlaxapi4vhyntrt7m1eukbvb6 
       foreign key (sala_nueva_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKnjwyynwb33g4jaat7k03korot 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKquuy4n6l595u3n1eesse65lm7 
       foreign key (estado_anterior_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKcduxdoctlihmlrf7jc79hktbr 
       foreign key (estado_nuevo_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK27v25jypoybt045dokcm47yul 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK28v16j834n0mxh44jrkouaard 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.lineas_investigacion 
       add constraint FK6mbdout54e5jy49tpaeqijaa8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.miembros_tribunal 
       add constraint FKrvimgktkif6hr7u3w0l2r345q 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.miembros_tribunal 
       add constraint FKii8qums5v0taxx349emm7th6g 
       foreign key (rol_jurado_id) 
       references presus.roles_jurado;

    alter table if exists presus.miembros_tribunal 
       add constraint FKebkpg7s5whbr9va2yvfaf1act 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists actas 
       add constraint FKbe1mhcpm4hh94m47oxihlkh6i 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists anteproyectos 
       add constraint FKnuplmmjrbs76slhxrt6swwytj 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists criterios_rubrica 
       add constraint FKrwb21y79trk780jwtk34aiqr3 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists cronograma 
       add constraint FKch4phbxqt1j7wck6fh34phj62 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists cronograma 
       add constraint FKbp2d8c5i4pgy0mbhae0f5cj78 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists cronograma 
       add constraint FKbt78p9nbvdowoh0dwisdpnk2n 
       foreign key (estado_id) 
       references presus.estados_cronograma;

    alter table if exists cronograma 
       add constraint FKnkurftcc1qsc7alh7276l5uq1 
       foreign key (sala_id) 
       references sala;

    alter table if exists cronograma 
       add constraint FK7wxxnuex9myk4vf3qbr8nm2qn 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists docente 
       add constraint FKroasnisuah9k11docjg9q46w6 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists docente 
       add constraint FKbs42aumodddav4mosgah3bomi 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists estudiante 
       add constraint FK6mibklpfbmshbwm5ly7t6quc1 
       foreign key (carrera_id) 
       references presus.carreras;

    alter table if exists estudiante 
       add constraint FK665t8l4wpufihhoes8s1938ht 
       foreign key (periodo_ingreso_id) 
       references presus.periodos_academicos;

    alter table if exists estudiante 
       add constraint FKmb0c2sqmehp6spvhm53mej2b7 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists evaluaciones 
       add constraint FKcw8bowlxco293tni77pshk0un 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists evaluaciones 
       add constraint FK53hknbr7ctsod58a57sbk99j9 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_criterio 
       add constraint FK704dbpt9dfb9cc4q2frdk1e59 
       foreign key (criterio_id) 
       references criterios_rubrica;

    alter table if exists evaluaciones_criterio 
       add constraint FKdsk8q9dykx4cndxxmyxg679fc 
       foreign key (evaluador_id) 
       references presus.evaluadores;

    alter table if exists evaluaciones_criterio 
       add constraint FKiwxwbpykr3vo23lxeimiwmfji 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_jurado 
       add constraint FK53wpgafopnaoqe0cge5mi09g8 
       foreign key (jurado_id) 
       references presus.miembros_tribunal;

    alter table if exists evaluaciones_jurado 
       add constraint FK3m5avtbjkv8okijdpvnba6br8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists notificaciones 
       add constraint FK1mxbjb81ft61gwlh0kabubndc 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK5lihp07xom3g6aiv6aid1mqoy 
       foreign key (actualizado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FKkocwlitlopkh7puo52h9tncxj 
       foreign key (area_tematica_id) 
       references presus.areas_tematicas;

    alter table if exists solicitud 
       add constraint FK4o0t4min6fnjh6wtewgwetdsc 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists solicitud 
       add constraint FKbslas51apjrlk1sspwjxcahpd 
       foreign key (creado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK3kdfcybjca99ian0k5g1mhhoq 
       foreign key (estado_id) 
       references presus.estados_solicitud;

    alter table if exists solicitud 
       add constraint FK1gfsheb54hb4313592ynmr5u4 
       foreign key (estudiante_id) 
       references estudiante;

    alter table if exists solicitud 
       add constraint FKg1jysw6105nj3u40g1ahsx14l 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists solicitud 
       add constraint FKaxmn3drihjstewcid9a1wjuw9 
       foreign key (modalidad_titulacion_id) 
       references presus.modalidades_titulacion;

    alter table if exists tutores 
       add constraint FKb2xb48y98w51rrxljckb63d92 
       foreign key (docente_id) 
       references docente;

    alter table if exists tutores 
       add constraint FKpva6fxtkmtc7e8y8qh3ci1jg8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists tutoria_fases 
       add constraint FKennbyt8lrhckfi7fwkpw8qgfm 
       foreign key (tutor_id) 
       references tutores;

    alter table if exists tutoria_mensajes 
       add constraint FK6otp7q57xutoo6yhs7m5vkn19 
       foreign key (fase_id) 
       references tutoria_fases;

    alter table if exists tutoria_mensajes 
       add constraint FKj3p4s6quhocjaojcdvw2t8ag2 
       foreign key (remitente_id) 
       references usuarios;

    alter table if exists usuarios 
       add constraint FKku0it797v3701ntswwvl95ei 
       foreign key (rol_id) 
       references presus.roles_usuario;

    create table presus.areas_tematicas (
        id serial not null,
        linea_investigacion_id integer not null,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.bloques_horarios (
        hora_fin time(6) not null,
        hora_inicio time(6) not null,
        id serial not null,
        jornada_id integer not null,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.carreras (
        facultad_id integer not null,
        id serial not null,
        codigo varchar(20) not null unique,
        modalidad_estudio varchar(40),
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.convocatorias_titulacion (
        activa boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        periodo_academico_id integer not null,
        codigo varchar(30) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.disponibilidad_sala (
        bloque_id integer not null,
        disponible boolean not null,
        fecha date not null,
        id bigserial not null,
        sala_id bigint not null,
        motivo varchar(200),
        primary key (id)
    );

    create table presus.estados_cronograma (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_proceso (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_solicitud (
        id serial not null,
        orden smallint not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.evaluaciones_finales (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado_promedio float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        resultado_id integer,
        fecha_calculo timestamp(6) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint not null unique,
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table presus.evaluadores (
        peso float(53) not null,
        tipo_evaluador_id integer not null,
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        miembro_tribunal_id bigint,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table presus.facultades (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.historial_cronograma (
        cronograma_id bigint not null,
        fecha_anterior timestamp(6) not null,
        fecha_cambio timestamp(6) not null,
        fecha_nueva timestamp(6) not null,
        id bigserial not null,
        sala_anterior_id bigint,
        sala_nueva_id bigint,
        usuario_id bigint not null,
        motivo TEXT,
        primary key (id)
    );

    create table presus.historial_estados_solicitud (
        estado_anterior_id integer,
        estado_nuevo_id integer not null,
        fecha_cambio timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null,
        usuario_id bigint not null,
        comentario TEXT,
        primary key (id)
    );

    create table presus.jornadas (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.lineas_investigacion (
        facultad_id integer,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.miembros_tribunal (
        confirmado boolean not null,
        rol_jurado_id integer not null,
        asignado_en timestamp(6) not null,
        docente_id bigint not null,
        id bigserial not null,
        solicitud_id bigint not null,
        primary key (id),
        unique (solicitud_id, docente_id)
    );

    create table presus.modalidades_titulacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table presus.periodos_academicos (
        activo boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(100) not null,
        primary key (id)
    );

    create table presus.resultados_evaluacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_jurado (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_usuario (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.tipos_evaluador (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.tipos_mensaje (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table actas (
        fecha_generacion date not null,
        firmada boolean not null,
        firmada_presidente boolean not null,
        firmada_tutor boolean not null,
        firmada_vocal1 boolean not null,
        firmada_vocal2 boolean not null,
        fecha_firma_presidente timestamp(6),
        fecha_firma_tutor timestamp(6),
        fecha_firma_vocal1 timestamp(6),
        fecha_firma_vocal2 timestamp(6),
        id bigserial not null,
        solicitud_id bigint not null unique,
        archivo_pdf varchar(255),
        observaciones_acta TEXT,
        primary key (id)
    );

    create table anteproyectos (
        fecha_envio date,
        id bigserial not null,
        solicitud_id bigint unique,
        tamano_bytes bigint,
        estado varchar(30),
        sha256_hash varchar(64),
        archivo_pdf varchar(255),
        observaciones TEXT,
        primary key (id)
    );

    create table criterios_rubrica (
        orden integer not null,
        ponderacion float(53) not null,
        id bigserial not null,
        rubrica_id bigint not null,
        nombre varchar(100) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table cronograma (
        bloque_id integer,
        convocatoria_id integer not null,
        duracion_min integer not null,
        estado_id integer not null,
        numero_intento smallint not null,
        creado_en timestamp(6) not null,
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        sala_id bigint not null,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table docente (
        carga_horaria_semanal integer not null,
        disponible boolean not null,
        facultad_id integer,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        area_especialidad varchar(180),
        primary key (id)
    );

    create table estudiante (
        carrera_id integer not null,
        periodo_ingreso_id integer,
        semestre_actual smallint not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        semestre varchar(30),
        telefono varchar(30),
        expediente_codigo varchar(60) unique,
        carrera varchar(180) not null,
        primary key (id)
    );

    create table evaluaciones (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint unique,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table evaluaciones_criterio (
        escala integer not null,
        nota_obtenida float(53) not null,
        criterio_id bigint not null,
        evaluador_id bigint not null,
        id bigserial not null,
        registrado_en timestamp(6) not null,
        solicitud_id bigint not null,
        observacion_auto TEXT,
        observacion_manual TEXT,
        observaciones TEXT,
        primary key (id),
        unique (evaluador_id, criterio_id)
    );

    create table evaluaciones_jurado (
        nota_jurado float(53) not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        jurado_id bigint not null,
        solicitud_id bigint not null,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table notificaciones (
        leida boolean not null,
        fecha timestamp(6),
        id bigserial not null,
        usuario_id bigint,
        mensaje TEXT,
        primary key (id)
    );

    create table rubricas (
        puntaje_maximo float(53) not null,
        id bigserial not null,
        nombre varchar(120) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table sala (
        capacidad integer not null,
        disponible boolean not null,
        id bigserial not null,
        codigo varchar(40) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table solicitud (
        area_tematica_id integer,
        convocatoria_id integer not null,
        estado_id integer not null,
        linea_investigacion_id integer,
        modalidad_titulacion_id integer not null,
        actualizado_en timestamp(6) not null,
        actualizado_por bigint,
        creado_por bigint,
        estudiante_id bigint not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        suspendido_en timestamp(6),
        titulo_tema varchar(300) not null,
        motivo_suspension TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table tutores (
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null unique,
        estado varchar(20) not null,
        observaciones TEXT,
        primary key (id)
    );

    create table tutoria_fases (
        numero_fase integer not null,
        fecha_aprobacion timestamp(6),
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        tamano_pdf_bytes bigint,
        tutor_id bigint not null,
        estado varchar(30) not null,
        sha256_pdf varchar(64),
        archivo_pdf_estudiante varchar(255),
        primary key (id)
    );

    create table tutoria_mensajes (
        leido boolean not null,
        fase_id bigint not null,
        fecha_envio timestamp(6) not null,
        id bigserial not null,
        remitente_id bigint not null,
        tipo varchar(20) not null,
        contenido TEXT not null,
        primary key (id)
    );

    create table usuarios (
        activo boolean not null,
        rol_id integer not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        apellido varchar(255) not null,
        email varchar(255) not null unique,
        email_notificaciones varchar(255),
        nombre varchar(255) not null,
        password varchar(255) not null,
        rol varchar(255) not null,
        telefono varchar(255),
        primary key (id)
    );

    alter table if exists presus.areas_tematicas 
       add constraint FK89neyi3j42yt914y9dsepvx8g 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists presus.bloques_horarios 
       add constraint FKhimm4vkb8aaamcb8ig77qk8jr 
       foreign key (jornada_id) 
       references presus.jornadas;

    alter table if exists presus.carreras 
       add constraint FKpkbqfnd3xcstklurnni1v7hi8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.convocatorias_titulacion 
       add constraint FKkhjxrhwxttrjg54fosa70k0ib 
       foreign key (periodo_academico_id) 
       references presus.periodos_academicos;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKaqxqt9i1aht1anwbwjtnxkjay 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKdnyk315lc3r3lxpja9ff5aa72 
       foreign key (sala_id) 
       references sala;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK1656v7687m5a006ig2dnxdxlq 
       foreign key (resultado_id) 
       references presus.resultados_evaluacion;

    alter table if exists presus.evaluaciones_finales 
       add constraint FKqr6nw8s42apawhtrjaufmemmk 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK6j0y0jr90cysn9b2xomrn2907 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKdcv3fm9ch7f9otbph1sc0kc56 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.evaluadores 
       add constraint FKf2c67wiobryo5c5us94dxo2nj 
       foreign key (miembro_tribunal_id) 
       references presus.miembros_tribunal;

    alter table if exists presus.evaluadores 
       add constraint FK7lfvwr8cap0mtqx82eypyrfkd 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKf7pg14kvrds8f3splp0a3d9m8 
       foreign key (tipo_evaluador_id) 
       references presus.tipos_evaluador;

    alter table if exists presus.historial_cronograma 
       add constraint FKi3w1x79h0hqgek4qn3a3m2j5x 
       foreign key (cronograma_id) 
       references cronograma;

    alter table if exists presus.historial_cronograma 
       add constraint FKaou7dy35isiktfxl0wvrv24c5 
       foreign key (sala_anterior_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKhlaxapi4vhyntrt7m1eukbvb6 
       foreign key (sala_nueva_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKnjwyynwb33g4jaat7k03korot 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKquuy4n6l595u3n1eesse65lm7 
       foreign key (estado_anterior_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKcduxdoctlihmlrf7jc79hktbr 
       foreign key (estado_nuevo_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK27v25jypoybt045dokcm47yul 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK28v16j834n0mxh44jrkouaard 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.lineas_investigacion 
       add constraint FK6mbdout54e5jy49tpaeqijaa8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.miembros_tribunal 
       add constraint FKrvimgktkif6hr7u3w0l2r345q 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.miembros_tribunal 
       add constraint FKii8qums5v0taxx349emm7th6g 
       foreign key (rol_jurado_id) 
       references presus.roles_jurado;

    alter table if exists presus.miembros_tribunal 
       add constraint FKebkpg7s5whbr9va2yvfaf1act 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists actas 
       add constraint FKbe1mhcpm4hh94m47oxihlkh6i 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists anteproyectos 
       add constraint FKnuplmmjrbs76slhxrt6swwytj 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists criterios_rubrica 
       add constraint FKrwb21y79trk780jwtk34aiqr3 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists cronograma 
       add constraint FKch4phbxqt1j7wck6fh34phj62 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists cronograma 
       add constraint FKbp2d8c5i4pgy0mbhae0f5cj78 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists cronograma 
       add constraint FKbt78p9nbvdowoh0dwisdpnk2n 
       foreign key (estado_id) 
       references presus.estados_cronograma;

    alter table if exists cronograma 
       add constraint FKnkurftcc1qsc7alh7276l5uq1 
       foreign key (sala_id) 
       references sala;

    alter table if exists cronograma 
       add constraint FK7wxxnuex9myk4vf3qbr8nm2qn 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists docente 
       add constraint FKroasnisuah9k11docjg9q46w6 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists docente 
       add constraint FKbs42aumodddav4mosgah3bomi 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists estudiante 
       add constraint FK6mibklpfbmshbwm5ly7t6quc1 
       foreign key (carrera_id) 
       references presus.carreras;

    alter table if exists estudiante 
       add constraint FK665t8l4wpufihhoes8s1938ht 
       foreign key (periodo_ingreso_id) 
       references presus.periodos_academicos;

    alter table if exists estudiante 
       add constraint FKmb0c2sqmehp6spvhm53mej2b7 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists evaluaciones 
       add constraint FKcw8bowlxco293tni77pshk0un 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists evaluaciones 
       add constraint FK53hknbr7ctsod58a57sbk99j9 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_criterio 
       add constraint FK704dbpt9dfb9cc4q2frdk1e59 
       foreign key (criterio_id) 
       references criterios_rubrica;

    alter table if exists evaluaciones_criterio 
       add constraint FKdsk8q9dykx4cndxxmyxg679fc 
       foreign key (evaluador_id) 
       references presus.evaluadores;

    alter table if exists evaluaciones_criterio 
       add constraint FKiwxwbpykr3vo23lxeimiwmfji 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_jurado 
       add constraint FK53wpgafopnaoqe0cge5mi09g8 
       foreign key (jurado_id) 
       references presus.miembros_tribunal;

    alter table if exists evaluaciones_jurado 
       add constraint FK3m5avtbjkv8okijdpvnba6br8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists notificaciones 
       add constraint FK1mxbjb81ft61gwlh0kabubndc 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK5lihp07xom3g6aiv6aid1mqoy 
       foreign key (actualizado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FKkocwlitlopkh7puo52h9tncxj 
       foreign key (area_tematica_id) 
       references presus.areas_tematicas;

    alter table if exists solicitud 
       add constraint FK4o0t4min6fnjh6wtewgwetdsc 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists solicitud 
       add constraint FKbslas51apjrlk1sspwjxcahpd 
       foreign key (creado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK3kdfcybjca99ian0k5g1mhhoq 
       foreign key (estado_id) 
       references presus.estados_solicitud;

    alter table if exists solicitud 
       add constraint FK1gfsheb54hb4313592ynmr5u4 
       foreign key (estudiante_id) 
       references estudiante;

    alter table if exists solicitud 
       add constraint FKg1jysw6105nj3u40g1ahsx14l 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists solicitud 
       add constraint FKaxmn3drihjstewcid9a1wjuw9 
       foreign key (modalidad_titulacion_id) 
       references presus.modalidades_titulacion;

    alter table if exists tutores 
       add constraint FKb2xb48y98w51rrxljckb63d92 
       foreign key (docente_id) 
       references docente;

    alter table if exists tutores 
       add constraint FKpva6fxtkmtc7e8y8qh3ci1jg8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists tutoria_fases 
       add constraint FKennbyt8lrhckfi7fwkpw8qgfm 
       foreign key (tutor_id) 
       references tutores;

    alter table if exists tutoria_mensajes 
       add constraint FK6otp7q57xutoo6yhs7m5vkn19 
       foreign key (fase_id) 
       references tutoria_fases;

    alter table if exists tutoria_mensajes 
       add constraint FKj3p4s6quhocjaojcdvw2t8ag2 
       foreign key (remitente_id) 
       references usuarios;

    alter table if exists usuarios 
       add constraint FKku0it797v3701ntswwvl95ei 
       foreign key (rol_id) 
       references presus.roles_usuario;

    create table presus.areas_tematicas (
        id serial not null,
        linea_investigacion_id integer not null,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.bloques_horarios (
        hora_fin time(6) not null,
        hora_inicio time(6) not null,
        id serial not null,
        jornada_id integer not null,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.carreras (
        facultad_id integer not null,
        id serial not null,
        codigo varchar(20) not null unique,
        modalidad_estudio varchar(40),
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.convocatorias_titulacion (
        activa boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        periodo_academico_id integer not null,
        codigo varchar(30) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.disponibilidad_sala (
        bloque_id integer not null,
        disponible boolean not null,
        fecha date not null,
        id bigserial not null,
        sala_id bigint not null,
        motivo varchar(200),
        primary key (id)
    );

    create table presus.estados_cronograma (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_proceso (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_solicitud (
        id serial not null,
        orden smallint not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.evaluaciones_finales (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado_promedio float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        resultado_id integer,
        fecha_calculo timestamp(6) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint not null unique,
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table presus.evaluadores (
        peso float(53) not null,
        tipo_evaluador_id integer not null,
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        miembro_tribunal_id bigint,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table presus.facultades (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.historial_cronograma (
        cronograma_id bigint not null,
        fecha_anterior timestamp(6) not null,
        fecha_cambio timestamp(6) not null,
        fecha_nueva timestamp(6) not null,
        id bigserial not null,
        sala_anterior_id bigint,
        sala_nueva_id bigint,
        usuario_id bigint not null,
        motivo TEXT,
        primary key (id)
    );

    create table presus.historial_estados_solicitud (
        estado_anterior_id integer,
        estado_nuevo_id integer not null,
        fecha_cambio timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null,
        usuario_id bigint not null,
        comentario TEXT,
        primary key (id)
    );

    create table presus.jornadas (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.lineas_investigacion (
        facultad_id integer,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.miembros_tribunal (
        confirmado boolean not null,
        rol_jurado_id integer not null,
        asignado_en timestamp(6) not null,
        docente_id bigint not null,
        id bigserial not null,
        solicitud_id bigint not null,
        primary key (id),
        unique (solicitud_id, docente_id)
    );

    create table presus.modalidades_titulacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table presus.periodos_academicos (
        activo boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(100) not null,
        primary key (id)
    );

    create table presus.resultados_evaluacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_jurado (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_usuario (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.tipos_evaluador (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.tipos_mensaje (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table actas (
        fecha_generacion date not null,
        firmada boolean not null,
        firmada_presidente boolean not null,
        firmada_tutor boolean not null,
        firmada_vocal1 boolean not null,
        firmada_vocal2 boolean not null,
        fecha_firma_presidente timestamp(6),
        fecha_firma_tutor timestamp(6),
        fecha_firma_vocal1 timestamp(6),
        fecha_firma_vocal2 timestamp(6),
        id bigserial not null,
        solicitud_id bigint not null unique,
        archivo_pdf varchar(255),
        observaciones_acta TEXT,
        primary key (id)
    );

    create table anteproyectos (
        fecha_envio date,
        id bigserial not null,
        solicitud_id bigint unique,
        tamano_bytes bigint,
        estado varchar(30),
        sha256_hash varchar(64),
        archivo_pdf varchar(255),
        observaciones TEXT,
        primary key (id)
    );

    create table criterios_rubrica (
        orden integer not null,
        ponderacion float(53) not null,
        id bigserial not null,
        rubrica_id bigint not null,
        nombre varchar(100) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table cronograma (
        bloque_id integer,
        convocatoria_id integer not null,
        duracion_min integer not null,
        estado_id integer not null,
        numero_intento smallint not null,
        creado_en timestamp(6) not null,
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        sala_id bigint not null,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table docente (
        carga_horaria_semanal integer not null,
        disponible boolean not null,
        facultad_id integer,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        area_especialidad varchar(180),
        primary key (id)
    );

    create table estudiante (
        carrera_id integer not null,
        periodo_ingreso_id integer,
        semestre_actual smallint not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        semestre varchar(30),
        telefono varchar(30),
        expediente_codigo varchar(60) unique,
        carrera varchar(180) not null,
        primary key (id)
    );

    create table evaluaciones (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint unique,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table evaluaciones_criterio (
        escala integer not null,
        nota_obtenida float(53) not null,
        criterio_id bigint not null,
        evaluador_id bigint not null,
        id bigserial not null,
        registrado_en timestamp(6) not null,
        solicitud_id bigint not null,
        observacion_auto TEXT,
        observacion_manual TEXT,
        observaciones TEXT,
        primary key (id),
        unique (evaluador_id, criterio_id)
    );

    create table evaluaciones_jurado (
        nota_jurado float(53) not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        jurado_id bigint not null,
        solicitud_id bigint not null,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table notificaciones (
        leida boolean not null,
        fecha timestamp(6),
        id bigserial not null,
        usuario_id bigint,
        mensaje TEXT,
        primary key (id)
    );

    create table rubricas (
        puntaje_maximo float(53) not null,
        id bigserial not null,
        nombre varchar(120) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table sala (
        capacidad integer not null,
        disponible boolean not null,
        id bigserial not null,
        codigo varchar(40) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table solicitud (
        area_tematica_id integer,
        convocatoria_id integer not null,
        estado_id integer not null,
        linea_investigacion_id integer,
        modalidad_titulacion_id integer not null,
        actualizado_en timestamp(6) not null,
        actualizado_por bigint,
        creado_por bigint,
        estudiante_id bigint not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        suspendido_en timestamp(6),
        titulo_tema varchar(300) not null,
        motivo_suspension TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table tutores (
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null unique,
        estado varchar(20) not null,
        observaciones TEXT,
        primary key (id)
    );

    create table tutoria_fases (
        numero_fase integer not null,
        fecha_aprobacion timestamp(6),
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        tamano_pdf_bytes bigint,
        tutor_id bigint not null,
        estado varchar(30) not null,
        sha256_pdf varchar(64),
        archivo_pdf_estudiante varchar(255),
        primary key (id)
    );

    create table tutoria_mensajes (
        leido boolean not null,
        fase_id bigint not null,
        fecha_envio timestamp(6) not null,
        id bigserial not null,
        remitente_id bigint not null,
        tipo varchar(20) not null,
        contenido TEXT not null,
        primary key (id)
    );

    create table usuarios (
        activo boolean not null,
        rol_id integer not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        apellido varchar(255) not null,
        email varchar(255) not null unique,
        email_notificaciones varchar(255),
        nombre varchar(255) not null,
        password varchar(255) not null,
        rol varchar(255) not null,
        telefono varchar(255),
        primary key (id)
    );

    alter table if exists presus.areas_tematicas 
       add constraint FK89neyi3j42yt914y9dsepvx8g 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists presus.bloques_horarios 
       add constraint FKhimm4vkb8aaamcb8ig77qk8jr 
       foreign key (jornada_id) 
       references presus.jornadas;

    alter table if exists presus.carreras 
       add constraint FKpkbqfnd3xcstklurnni1v7hi8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.convocatorias_titulacion 
       add constraint FKkhjxrhwxttrjg54fosa70k0ib 
       foreign key (periodo_academico_id) 
       references presus.periodos_academicos;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKaqxqt9i1aht1anwbwjtnxkjay 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKdnyk315lc3r3lxpja9ff5aa72 
       foreign key (sala_id) 
       references sala;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK1656v7687m5a006ig2dnxdxlq 
       foreign key (resultado_id) 
       references presus.resultados_evaluacion;

    alter table if exists presus.evaluaciones_finales 
       add constraint FKqr6nw8s42apawhtrjaufmemmk 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK6j0y0jr90cysn9b2xomrn2907 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKdcv3fm9ch7f9otbph1sc0kc56 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.evaluadores 
       add constraint FKf2c67wiobryo5c5us94dxo2nj 
       foreign key (miembro_tribunal_id) 
       references presus.miembros_tribunal;

    alter table if exists presus.evaluadores 
       add constraint FK7lfvwr8cap0mtqx82eypyrfkd 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKf7pg14kvrds8f3splp0a3d9m8 
       foreign key (tipo_evaluador_id) 
       references presus.tipos_evaluador;

    alter table if exists presus.historial_cronograma 
       add constraint FKi3w1x79h0hqgek4qn3a3m2j5x 
       foreign key (cronograma_id) 
       references cronograma;

    alter table if exists presus.historial_cronograma 
       add constraint FKaou7dy35isiktfxl0wvrv24c5 
       foreign key (sala_anterior_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKhlaxapi4vhyntrt7m1eukbvb6 
       foreign key (sala_nueva_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKnjwyynwb33g4jaat7k03korot 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKquuy4n6l595u3n1eesse65lm7 
       foreign key (estado_anterior_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKcduxdoctlihmlrf7jc79hktbr 
       foreign key (estado_nuevo_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK27v25jypoybt045dokcm47yul 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK28v16j834n0mxh44jrkouaard 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.lineas_investigacion 
       add constraint FK6mbdout54e5jy49tpaeqijaa8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.miembros_tribunal 
       add constraint FKrvimgktkif6hr7u3w0l2r345q 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.miembros_tribunal 
       add constraint FKii8qums5v0taxx349emm7th6g 
       foreign key (rol_jurado_id) 
       references presus.roles_jurado;

    alter table if exists presus.miembros_tribunal 
       add constraint FKebkpg7s5whbr9va2yvfaf1act 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists actas 
       add constraint FKbe1mhcpm4hh94m47oxihlkh6i 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists anteproyectos 
       add constraint FKnuplmmjrbs76slhxrt6swwytj 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists criterios_rubrica 
       add constraint FKrwb21y79trk780jwtk34aiqr3 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists cronograma 
       add constraint FKch4phbxqt1j7wck6fh34phj62 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists cronograma 
       add constraint FKbp2d8c5i4pgy0mbhae0f5cj78 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists cronograma 
       add constraint FKbt78p9nbvdowoh0dwisdpnk2n 
       foreign key (estado_id) 
       references presus.estados_cronograma;

    alter table if exists cronograma 
       add constraint FKnkurftcc1qsc7alh7276l5uq1 
       foreign key (sala_id) 
       references sala;

    alter table if exists cronograma 
       add constraint FK7wxxnuex9myk4vf3qbr8nm2qn 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists docente 
       add constraint FKroasnisuah9k11docjg9q46w6 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists docente 
       add constraint FKbs42aumodddav4mosgah3bomi 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists estudiante 
       add constraint FK6mibklpfbmshbwm5ly7t6quc1 
       foreign key (carrera_id) 
       references presus.carreras;

    alter table if exists estudiante 
       add constraint FK665t8l4wpufihhoes8s1938ht 
       foreign key (periodo_ingreso_id) 
       references presus.periodos_academicos;

    alter table if exists estudiante 
       add constraint FKmb0c2sqmehp6spvhm53mej2b7 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists evaluaciones 
       add constraint FKcw8bowlxco293tni77pshk0un 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists evaluaciones 
       add constraint FK53hknbr7ctsod58a57sbk99j9 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_criterio 
       add constraint FK704dbpt9dfb9cc4q2frdk1e59 
       foreign key (criterio_id) 
       references criterios_rubrica;

    alter table if exists evaluaciones_criterio 
       add constraint FKdsk8q9dykx4cndxxmyxg679fc 
       foreign key (evaluador_id) 
       references presus.evaluadores;

    alter table if exists evaluaciones_criterio 
       add constraint FKiwxwbpykr3vo23lxeimiwmfji 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_jurado 
       add constraint FK53wpgafopnaoqe0cge5mi09g8 
       foreign key (jurado_id) 
       references presus.miembros_tribunal;

    alter table if exists evaluaciones_jurado 
       add constraint FK3m5avtbjkv8okijdpvnba6br8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists notificaciones 
       add constraint FK1mxbjb81ft61gwlh0kabubndc 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK5lihp07xom3g6aiv6aid1mqoy 
       foreign key (actualizado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FKkocwlitlopkh7puo52h9tncxj 
       foreign key (area_tematica_id) 
       references presus.areas_tematicas;

    alter table if exists solicitud 
       add constraint FK4o0t4min6fnjh6wtewgwetdsc 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists solicitud 
       add constraint FKbslas51apjrlk1sspwjxcahpd 
       foreign key (creado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK3kdfcybjca99ian0k5g1mhhoq 
       foreign key (estado_id) 
       references presus.estados_solicitud;

    alter table if exists solicitud 
       add constraint FK1gfsheb54hb4313592ynmr5u4 
       foreign key (estudiante_id) 
       references estudiante;

    alter table if exists solicitud 
       add constraint FKg1jysw6105nj3u40g1ahsx14l 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists solicitud 
       add constraint FKaxmn3drihjstewcid9a1wjuw9 
       foreign key (modalidad_titulacion_id) 
       references presus.modalidades_titulacion;

    alter table if exists tutores 
       add constraint FKb2xb48y98w51rrxljckb63d92 
       foreign key (docente_id) 
       references docente;

    alter table if exists tutores 
       add constraint FKpva6fxtkmtc7e8y8qh3ci1jg8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists tutoria_fases 
       add constraint FKennbyt8lrhckfi7fwkpw8qgfm 
       foreign key (tutor_id) 
       references tutores;

    alter table if exists tutoria_mensajes 
       add constraint FK6otp7q57xutoo6yhs7m5vkn19 
       foreign key (fase_id) 
       references tutoria_fases;

    alter table if exists tutoria_mensajes 
       add constraint FKj3p4s6quhocjaojcdvw2t8ag2 
       foreign key (remitente_id) 
       references usuarios;

    alter table if exists usuarios 
       add constraint FKku0it797v3701ntswwvl95ei 
       foreign key (rol_id) 
       references presus.roles_usuario;

    create table presus.areas_tematicas (
        id serial not null,
        linea_investigacion_id integer not null,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.bloques_horarios (
        hora_fin time(6) not null,
        hora_inicio time(6) not null,
        id serial not null,
        jornada_id integer not null,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.carreras (
        facultad_id integer not null,
        id serial not null,
        codigo varchar(20) not null unique,
        modalidad_estudio varchar(40),
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.convocatorias_titulacion (
        activa boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        periodo_academico_id integer not null,
        codigo varchar(30) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.disponibilidad_sala (
        bloque_id integer not null,
        disponible boolean not null,
        fecha date not null,
        id bigserial not null,
        sala_id bigint not null,
        motivo varchar(200),
        primary key (id)
    );

    create table presus.estados_cronograma (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_proceso (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_solicitud (
        id serial not null,
        orden smallint not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.evaluaciones_finales (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado_promedio float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        resultado_id integer,
        fecha_calculo timestamp(6) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint not null unique,
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table presus.evaluadores (
        peso float(53) not null,
        tipo_evaluador_id integer not null,
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        miembro_tribunal_id bigint,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table presus.facultades (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.historial_cronograma (
        cronograma_id bigint not null,
        fecha_anterior timestamp(6) not null,
        fecha_cambio timestamp(6) not null,
        fecha_nueva timestamp(6) not null,
        id bigserial not null,
        sala_anterior_id bigint,
        sala_nueva_id bigint,
        usuario_id bigint not null,
        motivo TEXT,
        primary key (id)
    );

    create table presus.historial_estados_solicitud (
        estado_anterior_id integer,
        estado_nuevo_id integer not null,
        fecha_cambio timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null,
        usuario_id bigint not null,
        comentario TEXT,
        primary key (id)
    );

    create table presus.jornadas (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.lineas_investigacion (
        facultad_id integer,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.miembros_tribunal (
        confirmado boolean not null,
        rol_jurado_id integer not null,
        asignado_en timestamp(6) not null,
        docente_id bigint not null,
        id bigserial not null,
        solicitud_id bigint not null,
        primary key (id),
        unique (solicitud_id, docente_id)
    );

    create table presus.modalidades_titulacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table presus.periodos_academicos (
        activo boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(100) not null,
        primary key (id)
    );

    create table presus.resultados_evaluacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_jurado (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_usuario (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.tipos_evaluador (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.tipos_mensaje (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table actas (
        fecha_generacion date not null,
        firmada boolean not null,
        firmada_presidente boolean not null,
        firmada_tutor boolean not null,
        firmada_vocal1 boolean not null,
        firmada_vocal2 boolean not null,
        fecha_firma_presidente timestamp(6),
        fecha_firma_tutor timestamp(6),
        fecha_firma_vocal1 timestamp(6),
        fecha_firma_vocal2 timestamp(6),
        id bigserial not null,
        solicitud_id bigint not null unique,
        archivo_pdf varchar(255),
        observaciones_acta TEXT,
        primary key (id)
    );

    create table anteproyectos (
        fecha_envio date,
        id bigserial not null,
        solicitud_id bigint unique,
        tamano_bytes bigint,
        estado varchar(30),
        sha256_hash varchar(64),
        archivo_pdf varchar(255),
        observaciones TEXT,
        primary key (id)
    );

    create table criterios_rubrica (
        orden integer not null,
        ponderacion float(53) not null,
        id bigserial not null,
        rubrica_id bigint not null,
        nombre varchar(100) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table cronograma (
        bloque_id integer,
        convocatoria_id integer not null,
        duracion_min integer not null,
        estado_id integer not null,
        numero_intento smallint not null,
        creado_en timestamp(6) not null,
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        sala_id bigint not null,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table docente (
        carga_horaria_semanal integer not null,
        disponible boolean not null,
        facultad_id integer,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        area_especialidad varchar(180),
        primary key (id)
    );

    create table estudiante (
        carrera_id integer not null,
        periodo_ingreso_id integer,
        semestre_actual smallint not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        semestre varchar(30),
        telefono varchar(30),
        expediente_codigo varchar(60) unique,
        carrera varchar(180) not null,
        primary key (id)
    );

    create table evaluaciones (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint unique,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table evaluaciones_criterio (
        escala integer not null,
        nota_obtenida float(53) not null,
        criterio_id bigint not null,
        evaluador_id bigint not null,
        id bigserial not null,
        registrado_en timestamp(6) not null,
        solicitud_id bigint not null,
        observacion_auto TEXT,
        observacion_manual TEXT,
        observaciones TEXT,
        primary key (id),
        unique (evaluador_id, criterio_id)
    );

    create table evaluaciones_jurado (
        nota_jurado float(53) not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        jurado_id bigint not null,
        solicitud_id bigint not null,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table notificaciones (
        leida boolean not null,
        fecha timestamp(6),
        id bigserial not null,
        usuario_id bigint,
        mensaje TEXT,
        primary key (id)
    );

    create table rubricas (
        puntaje_maximo float(53) not null,
        id bigserial not null,
        nombre varchar(120) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table sala (
        capacidad integer not null,
        disponible boolean not null,
        id bigserial not null,
        codigo varchar(40) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table solicitud (
        area_tematica_id integer,
        convocatoria_id integer not null,
        estado_id integer not null,
        linea_investigacion_id integer,
        modalidad_titulacion_id integer not null,
        actualizado_en timestamp(6) not null,
        actualizado_por bigint,
        creado_por bigint,
        estudiante_id bigint not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        suspendido_en timestamp(6),
        titulo_tema varchar(300) not null,
        motivo_suspension TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table tutores (
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null unique,
        estado varchar(20) not null,
        observaciones TEXT,
        primary key (id)
    );

    create table tutoria_fases (
        numero_fase integer not null,
        fecha_aprobacion timestamp(6),
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        tamano_pdf_bytes bigint,
        tutor_id bigint not null,
        estado varchar(30) not null,
        sha256_pdf varchar(64),
        archivo_pdf_estudiante varchar(255),
        primary key (id)
    );

    create table tutoria_mensajes (
        leido boolean not null,
        fase_id bigint not null,
        fecha_envio timestamp(6) not null,
        id bigserial not null,
        remitente_id bigint not null,
        tipo varchar(20) not null,
        contenido TEXT not null,
        primary key (id)
    );

    create table usuarios (
        activo boolean not null,
        rol_id integer not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        apellido varchar(255) not null,
        email varchar(255) not null unique,
        email_notificaciones varchar(255),
        nombre varchar(255) not null,
        password varchar(255) not null,
        rol varchar(255) not null,
        telefono varchar(255),
        primary key (id)
    );

    alter table if exists presus.areas_tematicas 
       add constraint FK89neyi3j42yt914y9dsepvx8g 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists presus.bloques_horarios 
       add constraint FKhimm4vkb8aaamcb8ig77qk8jr 
       foreign key (jornada_id) 
       references presus.jornadas;

    alter table if exists presus.carreras 
       add constraint FKpkbqfnd3xcstklurnni1v7hi8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.convocatorias_titulacion 
       add constraint FKkhjxrhwxttrjg54fosa70k0ib 
       foreign key (periodo_academico_id) 
       references presus.periodos_academicos;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKaqxqt9i1aht1anwbwjtnxkjay 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKdnyk315lc3r3lxpja9ff5aa72 
       foreign key (sala_id) 
       references sala;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK1656v7687m5a006ig2dnxdxlq 
       foreign key (resultado_id) 
       references presus.resultados_evaluacion;

    alter table if exists presus.evaluaciones_finales 
       add constraint FKqr6nw8s42apawhtrjaufmemmk 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK6j0y0jr90cysn9b2xomrn2907 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKdcv3fm9ch7f9otbph1sc0kc56 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.evaluadores 
       add constraint FKf2c67wiobryo5c5us94dxo2nj 
       foreign key (miembro_tribunal_id) 
       references presus.miembros_tribunal;

    alter table if exists presus.evaluadores 
       add constraint FK7lfvwr8cap0mtqx82eypyrfkd 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKf7pg14kvrds8f3splp0a3d9m8 
       foreign key (tipo_evaluador_id) 
       references presus.tipos_evaluador;

    alter table if exists presus.historial_cronograma 
       add constraint FKi3w1x79h0hqgek4qn3a3m2j5x 
       foreign key (cronograma_id) 
       references cronograma;

    alter table if exists presus.historial_cronograma 
       add constraint FKaou7dy35isiktfxl0wvrv24c5 
       foreign key (sala_anterior_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKhlaxapi4vhyntrt7m1eukbvb6 
       foreign key (sala_nueva_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKnjwyynwb33g4jaat7k03korot 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKquuy4n6l595u3n1eesse65lm7 
       foreign key (estado_anterior_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKcduxdoctlihmlrf7jc79hktbr 
       foreign key (estado_nuevo_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK27v25jypoybt045dokcm47yul 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK28v16j834n0mxh44jrkouaard 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.lineas_investigacion 
       add constraint FK6mbdout54e5jy49tpaeqijaa8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.miembros_tribunal 
       add constraint FKrvimgktkif6hr7u3w0l2r345q 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.miembros_tribunal 
       add constraint FKii8qums5v0taxx349emm7th6g 
       foreign key (rol_jurado_id) 
       references presus.roles_jurado;

    alter table if exists presus.miembros_tribunal 
       add constraint FKebkpg7s5whbr9va2yvfaf1act 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists actas 
       add constraint FKbe1mhcpm4hh94m47oxihlkh6i 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists anteproyectos 
       add constraint FKnuplmmjrbs76slhxrt6swwytj 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists criterios_rubrica 
       add constraint FKrwb21y79trk780jwtk34aiqr3 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists cronograma 
       add constraint FKch4phbxqt1j7wck6fh34phj62 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists cronograma 
       add constraint FKbp2d8c5i4pgy0mbhae0f5cj78 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists cronograma 
       add constraint FKbt78p9nbvdowoh0dwisdpnk2n 
       foreign key (estado_id) 
       references presus.estados_cronograma;

    alter table if exists cronograma 
       add constraint FKnkurftcc1qsc7alh7276l5uq1 
       foreign key (sala_id) 
       references sala;

    alter table if exists cronograma 
       add constraint FK7wxxnuex9myk4vf3qbr8nm2qn 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists docente 
       add constraint FKroasnisuah9k11docjg9q46w6 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists docente 
       add constraint FKbs42aumodddav4mosgah3bomi 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists estudiante 
       add constraint FK6mibklpfbmshbwm5ly7t6quc1 
       foreign key (carrera_id) 
       references presus.carreras;

    alter table if exists estudiante 
       add constraint FK665t8l4wpufihhoes8s1938ht 
       foreign key (periodo_ingreso_id) 
       references presus.periodos_academicos;

    alter table if exists estudiante 
       add constraint FKmb0c2sqmehp6spvhm53mej2b7 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists evaluaciones 
       add constraint FKcw8bowlxco293tni77pshk0un 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists evaluaciones 
       add constraint FK53hknbr7ctsod58a57sbk99j9 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_criterio 
       add constraint FK704dbpt9dfb9cc4q2frdk1e59 
       foreign key (criterio_id) 
       references criterios_rubrica;

    alter table if exists evaluaciones_criterio 
       add constraint FKdsk8q9dykx4cndxxmyxg679fc 
       foreign key (evaluador_id) 
       references presus.evaluadores;

    alter table if exists evaluaciones_criterio 
       add constraint FKiwxwbpykr3vo23lxeimiwmfji 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_jurado 
       add constraint FK53wpgafopnaoqe0cge5mi09g8 
       foreign key (jurado_id) 
       references presus.miembros_tribunal;

    alter table if exists evaluaciones_jurado 
       add constraint FK3m5avtbjkv8okijdpvnba6br8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists notificaciones 
       add constraint FK1mxbjb81ft61gwlh0kabubndc 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK5lihp07xom3g6aiv6aid1mqoy 
       foreign key (actualizado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FKkocwlitlopkh7puo52h9tncxj 
       foreign key (area_tematica_id) 
       references presus.areas_tematicas;

    alter table if exists solicitud 
       add constraint FK4o0t4min6fnjh6wtewgwetdsc 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists solicitud 
       add constraint FKbslas51apjrlk1sspwjxcahpd 
       foreign key (creado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK3kdfcybjca99ian0k5g1mhhoq 
       foreign key (estado_id) 
       references presus.estados_solicitud;

    alter table if exists solicitud 
       add constraint FK1gfsheb54hb4313592ynmr5u4 
       foreign key (estudiante_id) 
       references estudiante;

    alter table if exists solicitud 
       add constraint FKg1jysw6105nj3u40g1ahsx14l 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists solicitud 
       add constraint FKaxmn3drihjstewcid9a1wjuw9 
       foreign key (modalidad_titulacion_id) 
       references presus.modalidades_titulacion;

    alter table if exists tutores 
       add constraint FKb2xb48y98w51rrxljckb63d92 
       foreign key (docente_id) 
       references docente;

    alter table if exists tutores 
       add constraint FKpva6fxtkmtc7e8y8qh3ci1jg8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists tutoria_fases 
       add constraint FKennbyt8lrhckfi7fwkpw8qgfm 
       foreign key (tutor_id) 
       references tutores;

    alter table if exists tutoria_mensajes 
       add constraint FK6otp7q57xutoo6yhs7m5vkn19 
       foreign key (fase_id) 
       references tutoria_fases;

    alter table if exists tutoria_mensajes 
       add constraint FKj3p4s6quhocjaojcdvw2t8ag2 
       foreign key (remitente_id) 
       references usuarios;

    alter table if exists usuarios 
       add constraint FKku0it797v3701ntswwvl95ei 
       foreign key (rol_id) 
       references presus.roles_usuario;

    create table presus.areas_tematicas (
        id serial not null,
        linea_investigacion_id integer not null,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.bloques_horarios (
        hora_fin time(6) not null,
        hora_inicio time(6) not null,
        id serial not null,
        jornada_id integer not null,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.carreras (
        facultad_id integer not null,
        id serial not null,
        codigo varchar(20) not null unique,
        modalidad_estudio varchar(40),
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.convocatorias_titulacion (
        activa boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        periodo_academico_id integer not null,
        codigo varchar(30) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.disponibilidad_sala (
        bloque_id integer not null,
        disponible boolean not null,
        fecha date not null,
        id bigserial not null,
        sala_id bigint not null,
        motivo varchar(200),
        primary key (id)
    );

    create table presus.estados_cronograma (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_proceso (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_solicitud (
        id serial not null,
        orden smallint not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.evaluaciones_finales (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado_promedio float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        resultado_id integer,
        fecha_calculo timestamp(6) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint not null unique,
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table presus.evaluadores (
        peso float(53) not null,
        tipo_evaluador_id integer not null,
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        miembro_tribunal_id bigint,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table presus.facultades (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.historial_cronograma (
        cronograma_id bigint not null,
        fecha_anterior timestamp(6) not null,
        fecha_cambio timestamp(6) not null,
        fecha_nueva timestamp(6) not null,
        id bigserial not null,
        sala_anterior_id bigint,
        sala_nueva_id bigint,
        usuario_id bigint not null,
        motivo TEXT,
        primary key (id)
    );

    create table presus.historial_estados_solicitud (
        estado_anterior_id integer,
        estado_nuevo_id integer not null,
        fecha_cambio timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null,
        usuario_id bigint not null,
        comentario TEXT,
        primary key (id)
    );

    create table presus.jornadas (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.lineas_investigacion (
        facultad_id integer,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.miembros_tribunal (
        confirmado boolean not null,
        rol_jurado_id integer not null,
        asignado_en timestamp(6) not null,
        docente_id bigint not null,
        id bigserial not null,
        solicitud_id bigint not null,
        primary key (id),
        unique (solicitud_id, docente_id)
    );

    create table presus.modalidades_titulacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table presus.periodos_academicos (
        activo boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(100) not null,
        primary key (id)
    );

    create table presus.resultados_evaluacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_jurado (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_usuario (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.tipos_evaluador (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.tipos_mensaje (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table actas (
        fecha_generacion date not null,
        firmada boolean not null,
        firmada_presidente boolean not null,
        firmada_tutor boolean not null,
        firmada_vocal1 boolean not null,
        firmada_vocal2 boolean not null,
        fecha_firma_presidente timestamp(6),
        fecha_firma_tutor timestamp(6),
        fecha_firma_vocal1 timestamp(6),
        fecha_firma_vocal2 timestamp(6),
        id bigserial not null,
        solicitud_id bigint not null unique,
        archivo_pdf varchar(255),
        observaciones_acta TEXT,
        primary key (id)
    );

    create table anteproyectos (
        fecha_envio date,
        id bigserial not null,
        solicitud_id bigint unique,
        tamano_bytes bigint,
        estado varchar(30),
        sha256_hash varchar(64),
        archivo_pdf varchar(255),
        observaciones TEXT,
        primary key (id)
    );

    create table criterios_rubrica (
        orden integer not null,
        ponderacion float(53) not null,
        id bigserial not null,
        rubrica_id bigint not null,
        nombre varchar(100) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table cronograma (
        bloque_id integer,
        convocatoria_id integer not null,
        duracion_min integer not null,
        estado_id integer not null,
        numero_intento smallint not null,
        creado_en timestamp(6) not null,
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        sala_id bigint not null,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table docente (
        carga_horaria_semanal integer not null,
        disponible boolean not null,
        facultad_id integer,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        area_especialidad varchar(180),
        primary key (id)
    );

    create table estudiante (
        carrera_id integer not null,
        periodo_ingreso_id integer,
        semestre_actual smallint not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        semestre varchar(30),
        telefono varchar(30),
        expediente_codigo varchar(60) unique,
        carrera varchar(180) not null,
        primary key (id)
    );

    create table evaluaciones (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint unique,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table evaluaciones_criterio (
        escala integer not null,
        nota_obtenida float(53) not null,
        criterio_id bigint not null,
        evaluador_id bigint not null,
        id bigserial not null,
        registrado_en timestamp(6) not null,
        solicitud_id bigint not null,
        observacion_auto TEXT,
        observacion_manual TEXT,
        observaciones TEXT,
        primary key (id),
        unique (evaluador_id, criterio_id)
    );

    create table evaluaciones_jurado (
        nota_jurado float(53) not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        jurado_id bigint not null,
        solicitud_id bigint not null,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table notificaciones (
        leida boolean not null,
        fecha timestamp(6),
        id bigserial not null,
        usuario_id bigint,
        mensaje TEXT,
        primary key (id)
    );

    create table rubricas (
        puntaje_maximo float(53) not null,
        id bigserial not null,
        nombre varchar(120) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table sala (
        capacidad integer not null,
        disponible boolean not null,
        id bigserial not null,
        codigo varchar(40) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table solicitud (
        area_tematica_id integer,
        convocatoria_id integer not null,
        estado_id integer not null,
        linea_investigacion_id integer,
        modalidad_titulacion_id integer not null,
        actualizado_en timestamp(6) not null,
        actualizado_por bigint,
        creado_por bigint,
        estudiante_id bigint not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        suspendido_en timestamp(6),
        titulo_tema varchar(300) not null,
        motivo_suspension TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table tutores (
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null unique,
        estado varchar(20) not null,
        observaciones TEXT,
        primary key (id)
    );

    create table tutoria_fases (
        numero_fase integer not null,
        fecha_aprobacion timestamp(6),
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        tamano_pdf_bytes bigint,
        tutor_id bigint not null,
        estado varchar(30) not null,
        sha256_pdf varchar(64),
        archivo_pdf_estudiante varchar(255),
        primary key (id)
    );

    create table tutoria_mensajes (
        leido boolean not null,
        fase_id bigint not null,
        fecha_envio timestamp(6) not null,
        id bigserial not null,
        remitente_id bigint not null,
        tipo varchar(20) not null,
        contenido TEXT not null,
        primary key (id)
    );

    create table usuarios (
        activo boolean not null,
        rol_id integer not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        apellido varchar(255) not null,
        email varchar(255) not null unique,
        email_notificaciones varchar(255),
        nombre varchar(255) not null,
        password varchar(255) not null,
        rol varchar(255) not null,
        telefono varchar(255),
        primary key (id)
    );

    alter table if exists presus.areas_tematicas 
       add constraint FK89neyi3j42yt914y9dsepvx8g 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists presus.bloques_horarios 
       add constraint FKhimm4vkb8aaamcb8ig77qk8jr 
       foreign key (jornada_id) 
       references presus.jornadas;

    alter table if exists presus.carreras 
       add constraint FKpkbqfnd3xcstklurnni1v7hi8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.convocatorias_titulacion 
       add constraint FKkhjxrhwxttrjg54fosa70k0ib 
       foreign key (periodo_academico_id) 
       references presus.periodos_academicos;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKaqxqt9i1aht1anwbwjtnxkjay 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKdnyk315lc3r3lxpja9ff5aa72 
       foreign key (sala_id) 
       references sala;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK1656v7687m5a006ig2dnxdxlq 
       foreign key (resultado_id) 
       references presus.resultados_evaluacion;

    alter table if exists presus.evaluaciones_finales 
       add constraint FKqr6nw8s42apawhtrjaufmemmk 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK6j0y0jr90cysn9b2xomrn2907 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKdcv3fm9ch7f9otbph1sc0kc56 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.evaluadores 
       add constraint FKf2c67wiobryo5c5us94dxo2nj 
       foreign key (miembro_tribunal_id) 
       references presus.miembros_tribunal;

    alter table if exists presus.evaluadores 
       add constraint FK7lfvwr8cap0mtqx82eypyrfkd 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKf7pg14kvrds8f3splp0a3d9m8 
       foreign key (tipo_evaluador_id) 
       references presus.tipos_evaluador;

    alter table if exists presus.historial_cronograma 
       add constraint FKi3w1x79h0hqgek4qn3a3m2j5x 
       foreign key (cronograma_id) 
       references cronograma;

    alter table if exists presus.historial_cronograma 
       add constraint FKaou7dy35isiktfxl0wvrv24c5 
       foreign key (sala_anterior_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKhlaxapi4vhyntrt7m1eukbvb6 
       foreign key (sala_nueva_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKnjwyynwb33g4jaat7k03korot 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKquuy4n6l595u3n1eesse65lm7 
       foreign key (estado_anterior_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKcduxdoctlihmlrf7jc79hktbr 
       foreign key (estado_nuevo_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK27v25jypoybt045dokcm47yul 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK28v16j834n0mxh44jrkouaard 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.lineas_investigacion 
       add constraint FK6mbdout54e5jy49tpaeqijaa8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.miembros_tribunal 
       add constraint FKrvimgktkif6hr7u3w0l2r345q 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.miembros_tribunal 
       add constraint FKii8qums5v0taxx349emm7th6g 
       foreign key (rol_jurado_id) 
       references presus.roles_jurado;

    alter table if exists presus.miembros_tribunal 
       add constraint FKebkpg7s5whbr9va2yvfaf1act 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists actas 
       add constraint FKbe1mhcpm4hh94m47oxihlkh6i 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists anteproyectos 
       add constraint FKnuplmmjrbs76slhxrt6swwytj 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists criterios_rubrica 
       add constraint FKrwb21y79trk780jwtk34aiqr3 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists cronograma 
       add constraint FKch4phbxqt1j7wck6fh34phj62 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists cronograma 
       add constraint FKbp2d8c5i4pgy0mbhae0f5cj78 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists cronograma 
       add constraint FKbt78p9nbvdowoh0dwisdpnk2n 
       foreign key (estado_id) 
       references presus.estados_cronograma;

    alter table if exists cronograma 
       add constraint FKnkurftcc1qsc7alh7276l5uq1 
       foreign key (sala_id) 
       references sala;

    alter table if exists cronograma 
       add constraint FK7wxxnuex9myk4vf3qbr8nm2qn 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists docente 
       add constraint FKroasnisuah9k11docjg9q46w6 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists docente 
       add constraint FKbs42aumodddav4mosgah3bomi 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists estudiante 
       add constraint FK6mibklpfbmshbwm5ly7t6quc1 
       foreign key (carrera_id) 
       references presus.carreras;

    alter table if exists estudiante 
       add constraint FK665t8l4wpufihhoes8s1938ht 
       foreign key (periodo_ingreso_id) 
       references presus.periodos_academicos;

    alter table if exists estudiante 
       add constraint FKmb0c2sqmehp6spvhm53mej2b7 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists evaluaciones 
       add constraint FKcw8bowlxco293tni77pshk0un 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists evaluaciones 
       add constraint FK53hknbr7ctsod58a57sbk99j9 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_criterio 
       add constraint FK704dbpt9dfb9cc4q2frdk1e59 
       foreign key (criterio_id) 
       references criterios_rubrica;

    alter table if exists evaluaciones_criterio 
       add constraint FKdsk8q9dykx4cndxxmyxg679fc 
       foreign key (evaluador_id) 
       references presus.evaluadores;

    alter table if exists evaluaciones_criterio 
       add constraint FKiwxwbpykr3vo23lxeimiwmfji 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_jurado 
       add constraint FK53wpgafopnaoqe0cge5mi09g8 
       foreign key (jurado_id) 
       references presus.miembros_tribunal;

    alter table if exists evaluaciones_jurado 
       add constraint FK3m5avtbjkv8okijdpvnba6br8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists notificaciones 
       add constraint FK1mxbjb81ft61gwlh0kabubndc 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK5lihp07xom3g6aiv6aid1mqoy 
       foreign key (actualizado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FKkocwlitlopkh7puo52h9tncxj 
       foreign key (area_tematica_id) 
       references presus.areas_tematicas;

    alter table if exists solicitud 
       add constraint FK4o0t4min6fnjh6wtewgwetdsc 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists solicitud 
       add constraint FKbslas51apjrlk1sspwjxcahpd 
       foreign key (creado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK3kdfcybjca99ian0k5g1mhhoq 
       foreign key (estado_id) 
       references presus.estados_solicitud;

    alter table if exists solicitud 
       add constraint FK1gfsheb54hb4313592ynmr5u4 
       foreign key (estudiante_id) 
       references estudiante;

    alter table if exists solicitud 
       add constraint FKg1jysw6105nj3u40g1ahsx14l 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists solicitud 
       add constraint FKaxmn3drihjstewcid9a1wjuw9 
       foreign key (modalidad_titulacion_id) 
       references presus.modalidades_titulacion;

    alter table if exists tutores 
       add constraint FKb2xb48y98w51rrxljckb63d92 
       foreign key (docente_id) 
       references docente;

    alter table if exists tutores 
       add constraint FKpva6fxtkmtc7e8y8qh3ci1jg8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists tutoria_fases 
       add constraint FKennbyt8lrhckfi7fwkpw8qgfm 
       foreign key (tutor_id) 
       references tutores;

    alter table if exists tutoria_mensajes 
       add constraint FK6otp7q57xutoo6yhs7m5vkn19 
       foreign key (fase_id) 
       references tutoria_fases;

    alter table if exists tutoria_mensajes 
       add constraint FKj3p4s6quhocjaojcdvw2t8ag2 
       foreign key (remitente_id) 
       references usuarios;

    alter table if exists usuarios 
       add constraint FKku0it797v3701ntswwvl95ei 
       foreign key (rol_id) 
       references presus.roles_usuario;

    create table presus.areas_tematicas (
        id serial not null,
        linea_investigacion_id integer not null,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.bloques_horarios (
        hora_fin time(6) not null,
        hora_inicio time(6) not null,
        id serial not null,
        jornada_id integer not null,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.carreras (
        facultad_id integer not null,
        id serial not null,
        codigo varchar(20) not null unique,
        modalidad_estudio varchar(40),
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.convocatorias_titulacion (
        activa boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        periodo_academico_id integer not null,
        codigo varchar(30) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.disponibilidad_sala (
        bloque_id integer not null,
        disponible boolean not null,
        fecha date not null,
        id bigserial not null,
        sala_id bigint not null,
        motivo varchar(200),
        primary key (id)
    );

    create table presus.estados_cronograma (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_proceso (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_solicitud (
        id serial not null,
        orden smallint not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.evaluaciones_finales (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado_promedio float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        resultado_id integer,
        fecha_calculo timestamp(6) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint not null unique,
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table presus.evaluadores (
        peso float(53) not null,
        tipo_evaluador_id integer not null,
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        miembro_tribunal_id bigint,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table presus.facultades (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.historial_cronograma (
        cronograma_id bigint not null,
        fecha_anterior timestamp(6) not null,
        fecha_cambio timestamp(6) not null,
        fecha_nueva timestamp(6) not null,
        id bigserial not null,
        sala_anterior_id bigint,
        sala_nueva_id bigint,
        usuario_id bigint not null,
        motivo TEXT,
        primary key (id)
    );

    create table presus.historial_estados_solicitud (
        estado_anterior_id integer,
        estado_nuevo_id integer not null,
        fecha_cambio timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null,
        usuario_id bigint not null,
        comentario TEXT,
        primary key (id)
    );

    create table presus.jornadas (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.lineas_investigacion (
        facultad_id integer,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.miembros_tribunal (
        confirmado boolean not null,
        rol_jurado_id integer not null,
        asignado_en timestamp(6) not null,
        docente_id bigint not null,
        id bigserial not null,
        solicitud_id bigint not null,
        primary key (id),
        unique (solicitud_id, docente_id)
    );

    create table presus.modalidades_titulacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table presus.periodos_academicos (
        activo boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(100) not null,
        primary key (id)
    );

    create table presus.resultados_evaluacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_jurado (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_usuario (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.tipos_evaluador (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.tipos_mensaje (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table actas (
        fecha_generacion date not null,
        firmada boolean not null,
        firmada_presidente boolean not null,
        firmada_tutor boolean not null,
        firmada_vocal1 boolean not null,
        firmada_vocal2 boolean not null,
        fecha_firma_presidente timestamp(6),
        fecha_firma_tutor timestamp(6),
        fecha_firma_vocal1 timestamp(6),
        fecha_firma_vocal2 timestamp(6),
        id bigserial not null,
        solicitud_id bigint not null unique,
        archivo_pdf varchar(255),
        observaciones_acta TEXT,
        primary key (id)
    );

    create table anteproyectos (
        fecha_envio date,
        id bigserial not null,
        solicitud_id bigint unique,
        tamano_bytes bigint,
        estado varchar(30),
        sha256_hash varchar(64),
        archivo_pdf varchar(255),
        observaciones TEXT,
        primary key (id)
    );

    create table criterios_rubrica (
        orden integer not null,
        ponderacion float(53) not null,
        id bigserial not null,
        rubrica_id bigint not null,
        nombre varchar(100) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table cronograma (
        bloque_id integer,
        convocatoria_id integer not null,
        duracion_min integer not null,
        estado_id integer not null,
        numero_intento smallint not null,
        creado_en timestamp(6) not null,
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        sala_id bigint not null,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table docente (
        carga_horaria_semanal integer not null,
        disponible boolean not null,
        facultad_id integer,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        area_especialidad varchar(180),
        primary key (id)
    );

    create table estudiante (
        carrera_id integer not null,
        periodo_ingreso_id integer,
        semestre_actual smallint not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        semestre varchar(30),
        telefono varchar(30),
        expediente_codigo varchar(60) unique,
        carrera varchar(180) not null,
        primary key (id)
    );

    create table evaluaciones (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint unique,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table evaluaciones_criterio (
        escala integer not null,
        nota_obtenida float(53) not null,
        criterio_id bigint not null,
        evaluador_id bigint not null,
        id bigserial not null,
        registrado_en timestamp(6) not null,
        solicitud_id bigint not null,
        observacion_auto TEXT,
        observacion_manual TEXT,
        observaciones TEXT,
        primary key (id),
        unique (evaluador_id, criterio_id)
    );

    create table evaluaciones_jurado (
        nota_jurado float(53) not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        jurado_id bigint not null,
        solicitud_id bigint not null,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table notificaciones (
        leida boolean not null,
        fecha timestamp(6),
        id bigserial not null,
        usuario_id bigint,
        mensaje TEXT,
        primary key (id)
    );

    create table rubricas (
        puntaje_maximo float(53) not null,
        id bigserial not null,
        nombre varchar(120) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table sala (
        capacidad integer not null,
        disponible boolean not null,
        id bigserial not null,
        codigo varchar(40) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table solicitud (
        area_tematica_id integer,
        convocatoria_id integer not null,
        estado_id integer not null,
        linea_investigacion_id integer,
        modalidad_titulacion_id integer not null,
        actualizado_en timestamp(6) not null,
        actualizado_por bigint,
        creado_por bigint,
        estudiante_id bigint not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        suspendido_en timestamp(6),
        titulo_tema varchar(300) not null,
        motivo_suspension TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table tutores (
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null unique,
        estado varchar(20) not null,
        observaciones TEXT,
        primary key (id)
    );

    create table tutoria_fases (
        numero_fase integer not null,
        fecha_aprobacion timestamp(6),
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        tamano_pdf_bytes bigint,
        tutor_id bigint not null,
        estado varchar(30) not null,
        sha256_pdf varchar(64),
        archivo_pdf_estudiante varchar(255),
        primary key (id)
    );

    create table tutoria_mensajes (
        leido boolean not null,
        fase_id bigint not null,
        fecha_envio timestamp(6) not null,
        id bigserial not null,
        remitente_id bigint not null,
        tipo varchar(20) not null,
        contenido TEXT not null,
        primary key (id)
    );

    create table usuarios (
        activo boolean not null,
        rol_id integer not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        apellido varchar(255) not null,
        email varchar(255) not null unique,
        email_notificaciones varchar(255),
        nombre varchar(255) not null,
        password varchar(255) not null,
        rol varchar(255) not null,
        telefono varchar(255),
        primary key (id)
    );

    alter table if exists presus.areas_tematicas 
       add constraint FK89neyi3j42yt914y9dsepvx8g 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists presus.bloques_horarios 
       add constraint FKhimm4vkb8aaamcb8ig77qk8jr 
       foreign key (jornada_id) 
       references presus.jornadas;

    alter table if exists presus.carreras 
       add constraint FKpkbqfnd3xcstklurnni1v7hi8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.convocatorias_titulacion 
       add constraint FKkhjxrhwxttrjg54fosa70k0ib 
       foreign key (periodo_academico_id) 
       references presus.periodos_academicos;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKaqxqt9i1aht1anwbwjtnxkjay 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKdnyk315lc3r3lxpja9ff5aa72 
       foreign key (sala_id) 
       references sala;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK1656v7687m5a006ig2dnxdxlq 
       foreign key (resultado_id) 
       references presus.resultados_evaluacion;

    alter table if exists presus.evaluaciones_finales 
       add constraint FKqr6nw8s42apawhtrjaufmemmk 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK6j0y0jr90cysn9b2xomrn2907 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKdcv3fm9ch7f9otbph1sc0kc56 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.evaluadores 
       add constraint FKf2c67wiobryo5c5us94dxo2nj 
       foreign key (miembro_tribunal_id) 
       references presus.miembros_tribunal;

    alter table if exists presus.evaluadores 
       add constraint FK7lfvwr8cap0mtqx82eypyrfkd 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKf7pg14kvrds8f3splp0a3d9m8 
       foreign key (tipo_evaluador_id) 
       references presus.tipos_evaluador;

    alter table if exists presus.historial_cronograma 
       add constraint FKi3w1x79h0hqgek4qn3a3m2j5x 
       foreign key (cronograma_id) 
       references cronograma;

    alter table if exists presus.historial_cronograma 
       add constraint FKaou7dy35isiktfxl0wvrv24c5 
       foreign key (sala_anterior_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKhlaxapi4vhyntrt7m1eukbvb6 
       foreign key (sala_nueva_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKnjwyynwb33g4jaat7k03korot 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKquuy4n6l595u3n1eesse65lm7 
       foreign key (estado_anterior_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKcduxdoctlihmlrf7jc79hktbr 
       foreign key (estado_nuevo_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK27v25jypoybt045dokcm47yul 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK28v16j834n0mxh44jrkouaard 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.lineas_investigacion 
       add constraint FK6mbdout54e5jy49tpaeqijaa8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.miembros_tribunal 
       add constraint FKrvimgktkif6hr7u3w0l2r345q 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.miembros_tribunal 
       add constraint FKii8qums5v0taxx349emm7th6g 
       foreign key (rol_jurado_id) 
       references presus.roles_jurado;

    alter table if exists presus.miembros_tribunal 
       add constraint FKebkpg7s5whbr9va2yvfaf1act 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists actas 
       add constraint FKbe1mhcpm4hh94m47oxihlkh6i 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists anteproyectos 
       add constraint FKnuplmmjrbs76slhxrt6swwytj 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists criterios_rubrica 
       add constraint FKrwb21y79trk780jwtk34aiqr3 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists cronograma 
       add constraint FKch4phbxqt1j7wck6fh34phj62 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists cronograma 
       add constraint FKbp2d8c5i4pgy0mbhae0f5cj78 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists cronograma 
       add constraint FKbt78p9nbvdowoh0dwisdpnk2n 
       foreign key (estado_id) 
       references presus.estados_cronograma;

    alter table if exists cronograma 
       add constraint FKnkurftcc1qsc7alh7276l5uq1 
       foreign key (sala_id) 
       references sala;

    alter table if exists cronograma 
       add constraint FK7wxxnuex9myk4vf3qbr8nm2qn 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists docente 
       add constraint FKroasnisuah9k11docjg9q46w6 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists docente 
       add constraint FKbs42aumodddav4mosgah3bomi 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists estudiante 
       add constraint FK6mibklpfbmshbwm5ly7t6quc1 
       foreign key (carrera_id) 
       references presus.carreras;

    alter table if exists estudiante 
       add constraint FK665t8l4wpufihhoes8s1938ht 
       foreign key (periodo_ingreso_id) 
       references presus.periodos_academicos;

    alter table if exists estudiante 
       add constraint FKmb0c2sqmehp6spvhm53mej2b7 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists evaluaciones 
       add constraint FKcw8bowlxco293tni77pshk0un 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists evaluaciones 
       add constraint FK53hknbr7ctsod58a57sbk99j9 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_criterio 
       add constraint FK704dbpt9dfb9cc4q2frdk1e59 
       foreign key (criterio_id) 
       references criterios_rubrica;

    alter table if exists evaluaciones_criterio 
       add constraint FKdsk8q9dykx4cndxxmyxg679fc 
       foreign key (evaluador_id) 
       references presus.evaluadores;

    alter table if exists evaluaciones_criterio 
       add constraint FKiwxwbpykr3vo23lxeimiwmfji 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_jurado 
       add constraint FK53wpgafopnaoqe0cge5mi09g8 
       foreign key (jurado_id) 
       references presus.miembros_tribunal;

    alter table if exists evaluaciones_jurado 
       add constraint FK3m5avtbjkv8okijdpvnba6br8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists notificaciones 
       add constraint FK1mxbjb81ft61gwlh0kabubndc 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK5lihp07xom3g6aiv6aid1mqoy 
       foreign key (actualizado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FKkocwlitlopkh7puo52h9tncxj 
       foreign key (area_tematica_id) 
       references presus.areas_tematicas;

    alter table if exists solicitud 
       add constraint FK4o0t4min6fnjh6wtewgwetdsc 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists solicitud 
       add constraint FKbslas51apjrlk1sspwjxcahpd 
       foreign key (creado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK3kdfcybjca99ian0k5g1mhhoq 
       foreign key (estado_id) 
       references presus.estados_solicitud;

    alter table if exists solicitud 
       add constraint FK1gfsheb54hb4313592ynmr5u4 
       foreign key (estudiante_id) 
       references estudiante;

    alter table if exists solicitud 
       add constraint FKg1jysw6105nj3u40g1ahsx14l 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists solicitud 
       add constraint FKaxmn3drihjstewcid9a1wjuw9 
       foreign key (modalidad_titulacion_id) 
       references presus.modalidades_titulacion;

    alter table if exists tutores 
       add constraint FKb2xb48y98w51rrxljckb63d92 
       foreign key (docente_id) 
       references docente;

    alter table if exists tutores 
       add constraint FKpva6fxtkmtc7e8y8qh3ci1jg8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists tutoria_fases 
       add constraint FKennbyt8lrhckfi7fwkpw8qgfm 
       foreign key (tutor_id) 
       references tutores;

    alter table if exists tutoria_mensajes 
       add constraint FK6otp7q57xutoo6yhs7m5vkn19 
       foreign key (fase_id) 
       references tutoria_fases;

    alter table if exists tutoria_mensajes 
       add constraint FKj3p4s6quhocjaojcdvw2t8ag2 
       foreign key (remitente_id) 
       references usuarios;

    alter table if exists usuarios 
       add constraint FKku0it797v3701ntswwvl95ei 
       foreign key (rol_id) 
       references presus.roles_usuario;

    create table presus.areas_tematicas (
        id serial not null,
        linea_investigacion_id integer not null,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.bloques_horarios (
        hora_fin time(6) not null,
        hora_inicio time(6) not null,
        id serial not null,
        jornada_id integer not null,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.carreras (
        facultad_id integer not null,
        id serial not null,
        codigo varchar(20) not null unique,
        modalidad_estudio varchar(40),
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.convocatorias_titulacion (
        activa boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        periodo_academico_id integer not null,
        codigo varchar(30) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.disponibilidad_sala (
        bloque_id integer not null,
        disponible boolean not null,
        fecha date not null,
        id bigserial not null,
        sala_id bigint not null,
        motivo varchar(200),
        primary key (id)
    );

    create table presus.estados_cronograma (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_proceso (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_solicitud (
        id serial not null,
        orden smallint not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.evaluaciones_finales (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado_promedio float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        resultado_id integer,
        fecha_calculo timestamp(6) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint not null unique,
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table presus.evaluadores (
        peso float(53) not null,
        tipo_evaluador_id integer not null,
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        miembro_tribunal_id bigint,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table presus.facultades (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.historial_cronograma (
        cronograma_id bigint not null,
        fecha_anterior timestamp(6) not null,
        fecha_cambio timestamp(6) not null,
        fecha_nueva timestamp(6) not null,
        id bigserial not null,
        sala_anterior_id bigint,
        sala_nueva_id bigint,
        usuario_id bigint not null,
        motivo TEXT,
        primary key (id)
    );

    create table presus.historial_estados_solicitud (
        estado_anterior_id integer,
        estado_nuevo_id integer not null,
        fecha_cambio timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null,
        usuario_id bigint not null,
        comentario TEXT,
        primary key (id)
    );

    create table presus.jornadas (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.lineas_investigacion (
        facultad_id integer,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.miembros_tribunal (
        confirmado boolean not null,
        rol_jurado_id integer not null,
        asignado_en timestamp(6) not null,
        docente_id bigint not null,
        id bigserial not null,
        solicitud_id bigint not null,
        primary key (id),
        unique (solicitud_id, docente_id)
    );

    create table presus.modalidades_titulacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table presus.periodos_academicos (
        activo boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(100) not null,
        primary key (id)
    );

    create table presus.resultados_evaluacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_jurado (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_usuario (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.tipos_evaluador (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.tipos_mensaje (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table actas (
        fecha_generacion date not null,
        firmada boolean not null,
        firmada_presidente boolean not null,
        firmada_tutor boolean not null,
        firmada_vocal1 boolean not null,
        firmada_vocal2 boolean not null,
        fecha_firma_presidente timestamp(6),
        fecha_firma_tutor timestamp(6),
        fecha_firma_vocal1 timestamp(6),
        fecha_firma_vocal2 timestamp(6),
        id bigserial not null,
        solicitud_id bigint not null unique,
        archivo_pdf varchar(255),
        observaciones_acta TEXT,
        primary key (id)
    );

    create table anteproyectos (
        fecha_envio date,
        id bigserial not null,
        solicitud_id bigint unique,
        tamano_bytes bigint,
        estado varchar(30),
        sha256_hash varchar(64),
        archivo_pdf varchar(255),
        observaciones TEXT,
        primary key (id)
    );

    create table criterios_rubrica (
        orden integer not null,
        ponderacion float(53) not null,
        id bigserial not null,
        rubrica_id bigint not null,
        nombre varchar(100) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table cronograma (
        bloque_id integer,
        convocatoria_id integer not null,
        duracion_min integer not null,
        estado_id integer not null,
        numero_intento smallint not null,
        creado_en timestamp(6) not null,
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        sala_id bigint not null,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table docente (
        carga_horaria_semanal integer not null,
        disponible boolean not null,
        facultad_id integer,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        area_especialidad varchar(180),
        primary key (id)
    );

    create table estudiante (
        carrera_id integer not null,
        periodo_ingreso_id integer,
        semestre_actual smallint not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        semestre varchar(30),
        telefono varchar(30),
        expediente_codigo varchar(60) unique,
        carrera varchar(180) not null,
        primary key (id)
    );

    create table evaluaciones (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint unique,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table evaluaciones_criterio (
        escala integer not null,
        nota_obtenida float(53) not null,
        criterio_id bigint not null,
        evaluador_id bigint not null,
        id bigserial not null,
        registrado_en timestamp(6) not null,
        solicitud_id bigint not null,
        observacion_auto TEXT,
        observacion_manual TEXT,
        observaciones TEXT,
        primary key (id),
        unique (evaluador_id, criterio_id)
    );

    create table evaluaciones_jurado (
        nota_jurado float(53) not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        jurado_id bigint not null,
        solicitud_id bigint not null,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table notificaciones (
        leida boolean not null,
        fecha timestamp(6),
        id bigserial not null,
        usuario_id bigint,
        mensaje TEXT,
        primary key (id)
    );

    create table rubricas (
        puntaje_maximo float(53) not null,
        id bigserial not null,
        nombre varchar(120) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table sala (
        capacidad integer not null,
        disponible boolean not null,
        id bigserial not null,
        codigo varchar(40) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table solicitud (
        area_tematica_id integer,
        convocatoria_id integer not null,
        estado_id integer not null,
        linea_investigacion_id integer,
        modalidad_titulacion_id integer not null,
        actualizado_en timestamp(6) not null,
        actualizado_por bigint,
        creado_por bigint,
        estudiante_id bigint not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        suspendido_en timestamp(6),
        titulo_tema varchar(300) not null,
        motivo_suspension TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table tutores (
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null unique,
        estado varchar(20) not null,
        observaciones TEXT,
        primary key (id)
    );

    create table tutoria_fases (
        numero_fase integer not null,
        fecha_aprobacion timestamp(6),
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        tamano_pdf_bytes bigint,
        tutor_id bigint not null,
        estado varchar(30) not null,
        sha256_pdf varchar(64),
        archivo_pdf_estudiante varchar(255),
        primary key (id)
    );

    create table tutoria_mensajes (
        leido boolean not null,
        fase_id bigint not null,
        fecha_envio timestamp(6) not null,
        id bigserial not null,
        remitente_id bigint not null,
        tipo varchar(20) not null,
        contenido TEXT not null,
        primary key (id)
    );

    create table usuarios (
        activo boolean not null,
        rol_id integer not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        apellido varchar(255) not null,
        email varchar(255) not null unique,
        email_notificaciones varchar(255),
        nombre varchar(255) not null,
        password varchar(255) not null,
        rol varchar(255) not null,
        telefono varchar(255),
        primary key (id)
    );

    alter table if exists presus.areas_tematicas 
       add constraint FK89neyi3j42yt914y9dsepvx8g 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists presus.bloques_horarios 
       add constraint FKhimm4vkb8aaamcb8ig77qk8jr 
       foreign key (jornada_id) 
       references presus.jornadas;

    alter table if exists presus.carreras 
       add constraint FKpkbqfnd3xcstklurnni1v7hi8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.convocatorias_titulacion 
       add constraint FKkhjxrhwxttrjg54fosa70k0ib 
       foreign key (periodo_academico_id) 
       references presus.periodos_academicos;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKaqxqt9i1aht1anwbwjtnxkjay 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKdnyk315lc3r3lxpja9ff5aa72 
       foreign key (sala_id) 
       references sala;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK1656v7687m5a006ig2dnxdxlq 
       foreign key (resultado_id) 
       references presus.resultados_evaluacion;

    alter table if exists presus.evaluaciones_finales 
       add constraint FKqr6nw8s42apawhtrjaufmemmk 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK6j0y0jr90cysn9b2xomrn2907 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKdcv3fm9ch7f9otbph1sc0kc56 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.evaluadores 
       add constraint FKf2c67wiobryo5c5us94dxo2nj 
       foreign key (miembro_tribunal_id) 
       references presus.miembros_tribunal;

    alter table if exists presus.evaluadores 
       add constraint FK7lfvwr8cap0mtqx82eypyrfkd 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKf7pg14kvrds8f3splp0a3d9m8 
       foreign key (tipo_evaluador_id) 
       references presus.tipos_evaluador;

    alter table if exists presus.historial_cronograma 
       add constraint FKi3w1x79h0hqgek4qn3a3m2j5x 
       foreign key (cronograma_id) 
       references cronograma;

    alter table if exists presus.historial_cronograma 
       add constraint FKaou7dy35isiktfxl0wvrv24c5 
       foreign key (sala_anterior_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKhlaxapi4vhyntrt7m1eukbvb6 
       foreign key (sala_nueva_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKnjwyynwb33g4jaat7k03korot 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKquuy4n6l595u3n1eesse65lm7 
       foreign key (estado_anterior_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKcduxdoctlihmlrf7jc79hktbr 
       foreign key (estado_nuevo_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK27v25jypoybt045dokcm47yul 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK28v16j834n0mxh44jrkouaard 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.lineas_investigacion 
       add constraint FK6mbdout54e5jy49tpaeqijaa8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.miembros_tribunal 
       add constraint FKrvimgktkif6hr7u3w0l2r345q 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.miembros_tribunal 
       add constraint FKii8qums5v0taxx349emm7th6g 
       foreign key (rol_jurado_id) 
       references presus.roles_jurado;

    alter table if exists presus.miembros_tribunal 
       add constraint FKebkpg7s5whbr9va2yvfaf1act 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists actas 
       add constraint FKbe1mhcpm4hh94m47oxihlkh6i 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists anteproyectos 
       add constraint FKnuplmmjrbs76slhxrt6swwytj 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists criterios_rubrica 
       add constraint FKrwb21y79trk780jwtk34aiqr3 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists cronograma 
       add constraint FKch4phbxqt1j7wck6fh34phj62 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists cronograma 
       add constraint FKbp2d8c5i4pgy0mbhae0f5cj78 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists cronograma 
       add constraint FKbt78p9nbvdowoh0dwisdpnk2n 
       foreign key (estado_id) 
       references presus.estados_cronograma;

    alter table if exists cronograma 
       add constraint FKnkurftcc1qsc7alh7276l5uq1 
       foreign key (sala_id) 
       references sala;

    alter table if exists cronograma 
       add constraint FK7wxxnuex9myk4vf3qbr8nm2qn 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists docente 
       add constraint FKroasnisuah9k11docjg9q46w6 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists docente 
       add constraint FKbs42aumodddav4mosgah3bomi 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists estudiante 
       add constraint FK6mibklpfbmshbwm5ly7t6quc1 
       foreign key (carrera_id) 
       references presus.carreras;

    alter table if exists estudiante 
       add constraint FK665t8l4wpufihhoes8s1938ht 
       foreign key (periodo_ingreso_id) 
       references presus.periodos_academicos;

    alter table if exists estudiante 
       add constraint FKmb0c2sqmehp6spvhm53mej2b7 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists evaluaciones 
       add constraint FKcw8bowlxco293tni77pshk0un 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists evaluaciones 
       add constraint FK53hknbr7ctsod58a57sbk99j9 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_criterio 
       add constraint FK704dbpt9dfb9cc4q2frdk1e59 
       foreign key (criterio_id) 
       references criterios_rubrica;

    alter table if exists evaluaciones_criterio 
       add constraint FKdsk8q9dykx4cndxxmyxg679fc 
       foreign key (evaluador_id) 
       references presus.evaluadores;

    alter table if exists evaluaciones_criterio 
       add constraint FKiwxwbpykr3vo23lxeimiwmfji 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_jurado 
       add constraint FK53wpgafopnaoqe0cge5mi09g8 
       foreign key (jurado_id) 
       references presus.miembros_tribunal;

    alter table if exists evaluaciones_jurado 
       add constraint FK3m5avtbjkv8okijdpvnba6br8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists notificaciones 
       add constraint FK1mxbjb81ft61gwlh0kabubndc 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK5lihp07xom3g6aiv6aid1mqoy 
       foreign key (actualizado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FKkocwlitlopkh7puo52h9tncxj 
       foreign key (area_tematica_id) 
       references presus.areas_tematicas;

    alter table if exists solicitud 
       add constraint FK4o0t4min6fnjh6wtewgwetdsc 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists solicitud 
       add constraint FKbslas51apjrlk1sspwjxcahpd 
       foreign key (creado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK3kdfcybjca99ian0k5g1mhhoq 
       foreign key (estado_id) 
       references presus.estados_solicitud;

    alter table if exists solicitud 
       add constraint FK1gfsheb54hb4313592ynmr5u4 
       foreign key (estudiante_id) 
       references estudiante;

    alter table if exists solicitud 
       add constraint FKg1jysw6105nj3u40g1ahsx14l 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists solicitud 
       add constraint FKaxmn3drihjstewcid9a1wjuw9 
       foreign key (modalidad_titulacion_id) 
       references presus.modalidades_titulacion;

    alter table if exists tutores 
       add constraint FKb2xb48y98w51rrxljckb63d92 
       foreign key (docente_id) 
       references docente;

    alter table if exists tutores 
       add constraint FKpva6fxtkmtc7e8y8qh3ci1jg8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists tutoria_fases 
       add constraint FKennbyt8lrhckfi7fwkpw8qgfm 
       foreign key (tutor_id) 
       references tutores;

    alter table if exists tutoria_mensajes 
       add constraint FK6otp7q57xutoo6yhs7m5vkn19 
       foreign key (fase_id) 
       references tutoria_fases;

    alter table if exists tutoria_mensajes 
       add constraint FKj3p4s6quhocjaojcdvw2t8ag2 
       foreign key (remitente_id) 
       references usuarios;

    alter table if exists usuarios 
       add constraint FKku0it797v3701ntswwvl95ei 
       foreign key (rol_id) 
       references presus.roles_usuario;

    create table presus.areas_tematicas (
        id serial not null,
        linea_investigacion_id integer not null,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.bloques_horarios (
        hora_fin time(6) not null,
        hora_inicio time(6) not null,
        id serial not null,
        jornada_id integer not null,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.carreras (
        facultad_id integer not null,
        id serial not null,
        codigo varchar(20) not null unique,
        modalidad_estudio varchar(40),
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.convocatorias_titulacion (
        activa boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        periodo_academico_id integer not null,
        codigo varchar(30) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.disponibilidad_sala (
        bloque_id integer not null,
        disponible boolean not null,
        fecha date not null,
        id bigserial not null,
        sala_id bigint not null,
        motivo varchar(200),
        primary key (id)
    );

    create table presus.estados_cronograma (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_proceso (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.estados_solicitud (
        id serial not null,
        orden smallint not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.evaluaciones_finales (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado_promedio float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        resultado_id integer,
        fecha_calculo timestamp(6) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint not null unique,
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table presus.evaluadores (
        peso float(53) not null,
        tipo_evaluador_id integer not null,
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        miembro_tribunal_id bigint,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table presus.facultades (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        primary key (id)
    );

    create table presus.historial_cronograma (
        cronograma_id bigint not null,
        fecha_anterior timestamp(6) not null,
        fecha_cambio timestamp(6) not null,
        fecha_nueva timestamp(6) not null,
        id bigserial not null,
        sala_anterior_id bigint,
        sala_nueva_id bigint,
        usuario_id bigint not null,
        motivo TEXT,
        primary key (id)
    );

    create table presus.historial_estados_solicitud (
        estado_anterior_id integer,
        estado_nuevo_id integer not null,
        fecha_cambio timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null,
        usuario_id bigint not null,
        comentario TEXT,
        primary key (id)
    );

    create table presus.jornadas (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.lineas_investigacion (
        facultad_id integer,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(150) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table presus.miembros_tribunal (
        confirmado boolean not null,
        rol_jurado_id integer not null,
        asignado_en timestamp(6) not null,
        docente_id bigint not null,
        id bigserial not null,
        solicitud_id bigint not null,
        primary key (id),
        unique (solicitud_id, docente_id)
    );

    create table presus.modalidades_titulacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table presus.periodos_academicos (
        activo boolean not null,
        fecha_fin date not null,
        fecha_inicio date not null,
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(100) not null,
        primary key (id)
    );

    create table presus.resultados_evaluacion (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_jurado (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.roles_usuario (
        id serial not null,
        codigo varchar(30) not null unique,
        nombre varchar(80) not null,
        primary key (id)
    );

    create table presus.tipos_evaluador (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table presus.tipos_mensaje (
        id serial not null,
        codigo varchar(20) not null unique,
        nombre varchar(60) not null,
        primary key (id)
    );

    create table actas (
        fecha_generacion date not null,
        firmada boolean not null,
        firmada_presidente boolean not null,
        firmada_tutor boolean not null,
        firmada_vocal1 boolean not null,
        firmada_vocal2 boolean not null,
        fecha_firma_presidente timestamp(6),
        fecha_firma_tutor timestamp(6),
        fecha_firma_vocal1 timestamp(6),
        fecha_firma_vocal2 timestamp(6),
        id bigserial not null,
        solicitud_id bigint not null unique,
        archivo_pdf varchar(255),
        observaciones_acta TEXT,
        primary key (id)
    );

    create table anteproyectos (
        fecha_envio date,
        id bigserial not null,
        solicitud_id bigint unique,
        tamano_bytes bigint,
        estado varchar(30),
        sha256_hash varchar(64),
        archivo_pdf varchar(255),
        observaciones TEXT,
        primary key (id)
    );

    create table criterios_rubrica (
        orden integer not null,
        ponderacion float(53) not null,
        id bigserial not null,
        rubrica_id bigint not null,
        nombre varchar(100) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table cronograma (
        bloque_id integer,
        convocatoria_id integer not null,
        duracion_min integer not null,
        estado_id integer not null,
        numero_intento smallint not null,
        creado_en timestamp(6) not null,
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        sala_id bigint not null,
        solicitud_id bigint not null,
        primary key (id)
    );

    create table docente (
        carga_horaria_semanal integer not null,
        disponible boolean not null,
        facultad_id integer,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        area_especialidad varchar(180),
        primary key (id)
    );

    create table estudiante (
        carrera_id integer not null,
        periodo_ingreso_id integer,
        semestre_actual smallint not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        usuario_id bigint not null unique,
        semestre varchar(30),
        telefono varchar(30),
        expediente_codigo varchar(60) unique,
        carrera varchar(180) not null,
        primary key (id)
    );

    create table evaluaciones (
        nota_final float(53),
        nota_instructor float(53),
        nota_jurado float(53),
        peso_instructor float(53) not null,
        peso_jurado float(53) not null,
        id bigserial not null,
        rubrica_id bigint,
        solicitud_id bigint unique,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table evaluaciones_criterio (
        escala integer not null,
        nota_obtenida float(53) not null,
        criterio_id bigint not null,
        evaluador_id bigint not null,
        id bigserial not null,
        registrado_en timestamp(6) not null,
        solicitud_id bigint not null,
        observacion_auto TEXT,
        observacion_manual TEXT,
        observaciones TEXT,
        primary key (id),
        unique (evaluador_id, criterio_id)
    );

    create table evaluaciones_jurado (
        nota_jurado float(53) not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        jurado_id bigint not null,
        solicitud_id bigint not null,
        resultado varchar(20),
        comentario_preestablecido TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table notificaciones (
        leida boolean not null,
        fecha timestamp(6),
        id bigserial not null,
        usuario_id bigint,
        mensaje TEXT,
        primary key (id)
    );

    create table rubricas (
        puntaje_maximo float(53) not null,
        id bigserial not null,
        nombre varchar(120) not null,
        descripcion TEXT,
        primary key (id)
    );

    create table sala (
        capacidad integer not null,
        disponible boolean not null,
        id bigserial not null,
        codigo varchar(40) not null unique,
        nombre varchar(120) not null,
        primary key (id)
    );

    create table solicitud (
        area_tematica_id integer,
        convocatoria_id integer not null,
        estado_id integer not null,
        linea_investigacion_id integer,
        modalidad_titulacion_id integer not null,
        actualizado_en timestamp(6) not null,
        actualizado_por bigint,
        creado_por bigint,
        estudiante_id bigint not null,
        fecha_registro timestamp(6) not null,
        id bigserial not null,
        suspendido_en timestamp(6),
        titulo_tema varchar(300) not null,
        motivo_suspension TEXT,
        observaciones TEXT,
        primary key (id)
    );

    create table tutores (
        docente_id bigint not null,
        fecha_asignacion timestamp(6) not null,
        id bigserial not null,
        solicitud_id bigint not null unique,
        estado varchar(20) not null,
        observaciones TEXT,
        primary key (id)
    );

    create table tutoria_fases (
        numero_fase integer not null,
        fecha_aprobacion timestamp(6),
        fecha_inicio timestamp(6) not null,
        id bigserial not null,
        tamano_pdf_bytes bigint,
        tutor_id bigint not null,
        estado varchar(30) not null,
        sha256_pdf varchar(64),
        archivo_pdf_estudiante varchar(255),
        primary key (id)
    );

    create table tutoria_mensajes (
        leido boolean not null,
        fase_id bigint not null,
        fecha_envio timestamp(6) not null,
        id bigserial not null,
        remitente_id bigint not null,
        tipo varchar(20) not null,
        contenido TEXT not null,
        primary key (id)
    );

    create table usuarios (
        activo boolean not null,
        rol_id integer not null,
        creado_en timestamp(6) not null,
        id bigserial not null,
        apellido varchar(255) not null,
        email varchar(255) not null unique,
        email_notificaciones varchar(255),
        nombre varchar(255) not null,
        password varchar(255) not null,
        rol varchar(255) not null,
        telefono varchar(255),
        primary key (id)
    );

    alter table if exists presus.areas_tematicas 
       add constraint FK89neyi3j42yt914y9dsepvx8g 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists presus.bloques_horarios 
       add constraint FKhimm4vkb8aaamcb8ig77qk8jr 
       foreign key (jornada_id) 
       references presus.jornadas;

    alter table if exists presus.carreras 
       add constraint FKpkbqfnd3xcstklurnni1v7hi8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.convocatorias_titulacion 
       add constraint FKkhjxrhwxttrjg54fosa70k0ib 
       foreign key (periodo_academico_id) 
       references presus.periodos_academicos;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKaqxqt9i1aht1anwbwjtnxkjay 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists presus.disponibilidad_sala 
       add constraint FKdnyk315lc3r3lxpja9ff5aa72 
       foreign key (sala_id) 
       references sala;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK1656v7687m5a006ig2dnxdxlq 
       foreign key (resultado_id) 
       references presus.resultados_evaluacion;

    alter table if exists presus.evaluaciones_finales 
       add constraint FKqr6nw8s42apawhtrjaufmemmk 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists presus.evaluaciones_finales 
       add constraint FK6j0y0jr90cysn9b2xomrn2907 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKdcv3fm9ch7f9otbph1sc0kc56 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.evaluadores 
       add constraint FKf2c67wiobryo5c5us94dxo2nj 
       foreign key (miembro_tribunal_id) 
       references presus.miembros_tribunal;

    alter table if exists presus.evaluadores 
       add constraint FK7lfvwr8cap0mtqx82eypyrfkd 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.evaluadores 
       add constraint FKf7pg14kvrds8f3splp0a3d9m8 
       foreign key (tipo_evaluador_id) 
       references presus.tipos_evaluador;

    alter table if exists presus.historial_cronograma 
       add constraint FKi3w1x79h0hqgek4qn3a3m2j5x 
       foreign key (cronograma_id) 
       references cronograma;

    alter table if exists presus.historial_cronograma 
       add constraint FKaou7dy35isiktfxl0wvrv24c5 
       foreign key (sala_anterior_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKhlaxapi4vhyntrt7m1eukbvb6 
       foreign key (sala_nueva_id) 
       references sala;

    alter table if exists presus.historial_cronograma 
       add constraint FKnjwyynwb33g4jaat7k03korot 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKquuy4n6l595u3n1eesse65lm7 
       foreign key (estado_anterior_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FKcduxdoctlihmlrf7jc79hktbr 
       foreign key (estado_nuevo_id) 
       references presus.estados_solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK27v25jypoybt045dokcm47yul 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists presus.historial_estados_solicitud 
       add constraint FK28v16j834n0mxh44jrkouaard 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists presus.lineas_investigacion 
       add constraint FK6mbdout54e5jy49tpaeqijaa8 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists presus.miembros_tribunal 
       add constraint FKrvimgktkif6hr7u3w0l2r345q 
       foreign key (docente_id) 
       references docente;

    alter table if exists presus.miembros_tribunal 
       add constraint FKii8qums5v0taxx349emm7th6g 
       foreign key (rol_jurado_id) 
       references presus.roles_jurado;

    alter table if exists presus.miembros_tribunal 
       add constraint FKebkpg7s5whbr9va2yvfaf1act 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists actas 
       add constraint FKbe1mhcpm4hh94m47oxihlkh6i 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists anteproyectos 
       add constraint FKnuplmmjrbs76slhxrt6swwytj 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists criterios_rubrica 
       add constraint FKrwb21y79trk780jwtk34aiqr3 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists cronograma 
       add constraint FKch4phbxqt1j7wck6fh34phj62 
       foreign key (bloque_id) 
       references presus.bloques_horarios;

    alter table if exists cronograma 
       add constraint FKbp2d8c5i4pgy0mbhae0f5cj78 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists cronograma 
       add constraint FKbt78p9nbvdowoh0dwisdpnk2n 
       foreign key (estado_id) 
       references presus.estados_cronograma;

    alter table if exists cronograma 
       add constraint FKnkurftcc1qsc7alh7276l5uq1 
       foreign key (sala_id) 
       references sala;

    alter table if exists cronograma 
       add constraint FK7wxxnuex9myk4vf3qbr8nm2qn 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists docente 
       add constraint FKroasnisuah9k11docjg9q46w6 
       foreign key (facultad_id) 
       references presus.facultades;

    alter table if exists docente 
       add constraint FKbs42aumodddav4mosgah3bomi 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists estudiante 
       add constraint FK6mibklpfbmshbwm5ly7t6quc1 
       foreign key (carrera_id) 
       references presus.carreras;

    alter table if exists estudiante 
       add constraint FK665t8l4wpufihhoes8s1938ht 
       foreign key (periodo_ingreso_id) 
       references presus.periodos_academicos;

    alter table if exists estudiante 
       add constraint FKmb0c2sqmehp6spvhm53mej2b7 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists evaluaciones 
       add constraint FKcw8bowlxco293tni77pshk0un 
       foreign key (rubrica_id) 
       references rubricas;

    alter table if exists evaluaciones 
       add constraint FK53hknbr7ctsod58a57sbk99j9 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_criterio 
       add constraint FK704dbpt9dfb9cc4q2frdk1e59 
       foreign key (criterio_id) 
       references criterios_rubrica;

    alter table if exists evaluaciones_criterio 
       add constraint FKdsk8q9dykx4cndxxmyxg679fc 
       foreign key (evaluador_id) 
       references presus.evaluadores;

    alter table if exists evaluaciones_criterio 
       add constraint FKiwxwbpykr3vo23lxeimiwmfji 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists evaluaciones_jurado 
       add constraint FK53wpgafopnaoqe0cge5mi09g8 
       foreign key (jurado_id) 
       references presus.miembros_tribunal;

    alter table if exists evaluaciones_jurado 
       add constraint FK3m5avtbjkv8okijdpvnba6br8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists notificaciones 
       add constraint FK1mxbjb81ft61gwlh0kabubndc 
       foreign key (usuario_id) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK5lihp07xom3g6aiv6aid1mqoy 
       foreign key (actualizado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FKkocwlitlopkh7puo52h9tncxj 
       foreign key (area_tematica_id) 
       references presus.areas_tematicas;

    alter table if exists solicitud 
       add constraint FK4o0t4min6fnjh6wtewgwetdsc 
       foreign key (convocatoria_id) 
       references presus.convocatorias_titulacion;

    alter table if exists solicitud 
       add constraint FKbslas51apjrlk1sspwjxcahpd 
       foreign key (creado_por) 
       references usuarios;

    alter table if exists solicitud 
       add constraint FK3kdfcybjca99ian0k5g1mhhoq 
       foreign key (estado_id) 
       references presus.estados_solicitud;

    alter table if exists solicitud 
       add constraint FK1gfsheb54hb4313592ynmr5u4 
       foreign key (estudiante_id) 
       references estudiante;

    alter table if exists solicitud 
       add constraint FKg1jysw6105nj3u40g1ahsx14l 
       foreign key (linea_investigacion_id) 
       references presus.lineas_investigacion;

    alter table if exists solicitud 
       add constraint FKaxmn3drihjstewcid9a1wjuw9 
       foreign key (modalidad_titulacion_id) 
       references presus.modalidades_titulacion;

    alter table if exists tutores 
       add constraint FKb2xb48y98w51rrxljckb63d92 
       foreign key (docente_id) 
       references docente;

    alter table if exists tutores 
       add constraint FKpva6fxtkmtc7e8y8qh3ci1jg8 
       foreign key (solicitud_id) 
       references solicitud;

    alter table if exists tutoria_fases 
       add constraint FKennbyt8lrhckfi7fwkpw8qgfm 
       foreign key (tutor_id) 
       references tutores;

    alter table if exists tutoria_mensajes 
       add constraint FK6otp7q57xutoo6yhs7m5vkn19 
       foreign key (fase_id) 
       references tutoria_fases;

    alter table if exists tutoria_mensajes 
       add constraint FKj3p4s6quhocjaojcdvw2t8ag2 
       foreign key (remitente_id) 
       references usuarios;

    alter table if exists usuarios 
       add constraint FKku0it797v3701ntswwvl95ei 
       foreign key (rol_id) 
       references presus.roles_usuario;
